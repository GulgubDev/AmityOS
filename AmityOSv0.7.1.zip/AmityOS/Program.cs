﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace AmityOS
{
    class Program
    {

const string SaveFilePath = "amityos_save.json";
class SaveData
{
    public string ActiveFolder { get; set; }
    public int HostPort { get; set; }
    public int CurrentConnectionPort { get; set; }
    public string CurrentConnectionName { get; set; }
    public Dictionary<string, DeviceSaveData> Devices { get; set; } = new();
    public Dictionary<string, string> PackageRepo { get; set; } = new();
}

class DeviceSaveData
{
    public string Name { get; set; }
    public List<int> Ports { get; set; } = new();
    public List<int> ListeningPorts { get; set; } = new();
    public Dictionary<string, List<string>> Folders { get; set; } = new();
    public Dictionary<string, string> Files { get; set; } = new();
    public List<string> MessageQueue { get; set; } = new();
}

        // ----------------------------------------------------
        // Device model for mock networking
        // ----------------------------------------------------
        class Device
        {
            public string Name { get; set; }
            public List<int> Ports { get; set; } = new();
            public HashSet<int> ListeningPorts { get; set; } = new();
            public Dictionary<string, List<string>> Folders { get; set; }
            public Dictionary<string, string> Files { get; set; }
            public Queue<string> MessageQueue { get; set; } = new();
        }

        // ----------------------------------------------------
        // PKG Script Runtime State
        // ----------------------------------------------------
        class PkgRuntime
        {
            public Dictionary<string, string> Vars { get; set; } = new();
            public Dictionary<string, bool> Bools { get; set; } = new();
            public Dictionary<string, List<string>> Functions { get; set; } = new();
            public Dictionary<string, int> FunctionLineMap { get; set; } = new();
            public Stack<string> Stack { get; set; } = new();
            public List<string> List { get; set; } = new();
            public Dictionary<string, int> LoopCounters { get; set; } = new();
            public bool ShouldExit { get; set; } = false;
            public bool ShouldBreak { get; set; } = false;
            public bool ShouldContinue { get; set; } = false;
            public string PkgName { get; set; } = "";
            public string PkgVersion { get; set; } = "0.0";
            public string PkgFile { get; set; } = "";
            public List<string> AllLines { get; set; } = new();
            public int CurrentLine { get; set; } = 0;
            public Dictionary<string, int> Labels { get; set; } = new();
        }

        // Hardcoded package repository
        static Dictionary<string, string> packageRepo = new()
        {
            
        };

        // Permissions data
        static HashSet<string> protectedFolders = new();
        static HashSet<string> lockedFiles = new();
        static Dictionary<string, string> devicePasswords = new();

        // Global state (we operate on the activeDevice)
        static Dictionary<int, Device> networkDevices = new();
        static int currentConnectionPort = 0;
        static string currentConnectionName = "";
        static string currentConnectionOwner = "";

        static Device hostDevice;
        static Device activeDevice;
        static int hostPort = 1000;
        static string activeFolder = "C:/";

        static Dictionary<string, Action<string>> appHandlers = new();

        const string PermsPath = "C:/os/config/perms.cfg";
        const string OsVersion = "0.7.1";

        // ---------------- pkgbuild state helpers ----------------
        class BldPackage
        {
            public string PkgName = "";
            public string Version = "0.0";
            public string OutFile = "";
            public string Entry = "";
            public Dictionary<string, string> Meta = new();
            public List<string> Files = new();
            public List<string> Boxes = new();
            public Dictionary<string, string> FileContents = new();
            public bool Compress = false;
            public List<string> Depends = new();
        }

        static void Main(string[] args)
{
    Console.Title = "AmityOS";
    Console.WriteLine($"AmityOS Kernel v.{OsVersion} loaded\n");

    appHandlers[".txt"] = path => OpenTextFile(path);
    appHandlers[".app"] = path => LaunchApp(path);
    appHandlers[".pkg"] = path => RunPackage(path);
    appHandlers[".cfg"] = path => OpenTextFile(path);

    // Try to load previous session
    bool loaded = LoadState();

    if (!loaded)
    {
        // Fresh start
        var hostFolders = new Dictionary<string, List<string>>()
        {
            { "C:/",              new List<string> { "os", "user" } },
            { "C:/os/",           new List<string> { "bin", "config" } },
            { "C:/os/bin/",       new List<string>() },
            { "C:/os/config/",    new List<string>() },
            { "C:/user/",         new List<string> { "downloads" } },
            { "C:/user/downloads/", new List<string>() },
        };

        var hostFiles = new Dictionary<string, string>();

        hostDevice = new Device
        {
            Name = "host",
            Ports = new List<int> { hostPort },
            ListeningPorts = new HashSet<int>(),
            Folders = hostFolders,
            Files = hostFiles
        };
        networkDevices[hostPort] = hostDevice;

        activeDevice = hostDevice;
        activeFolder = "C:/";

        Console.WriteLine("New session started.");
    }

    Console.WriteLine("For more information, type help\n");
    CommandLoop();
}

        // Rest of the code continues from here...
        // (All the static methods from the previous code go here)

static void SaveState()
{
    try
    {
        var save = new SaveData
        {
            ActiveFolder = activeFolder,
            HostPort = hostPort,
            CurrentConnectionPort = currentConnectionPort,
            CurrentConnectionName = currentConnectionName ?? "",
            PackageRepo = new Dictionary<string, string>(packageRepo)
        };

        foreach (var kvp in networkDevices)
        {
            var dev = kvp.Value;
            var devSave = new DeviceSaveData
            {
                Name = dev.Name,
                Ports = new List<int>(dev.Ports),
                ListeningPorts = new List<int>(dev.ListeningPorts),
                Folders = new Dictionary<string, List<string>>(),
                Files = new Dictionary<string, string>(dev.Files),
                MessageQueue = new List<string>(dev.MessageQueue)
            };

            foreach (var folder in dev.Folders)
                devSave.Folders[folder.Key] = new List<string>(folder.Value);

            save.Devices[kvp.Key.ToString()] = devSave;
        }

        var options = new JsonSerializerOptions { WriteIndented = true };
        string json = JsonSerializer.Serialize(save, options);
        System.IO.File.WriteAllText(SaveFilePath, json);
        Console.WriteLine("Session saved successfully.");
    }
    catch (Exception ex)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine($"Failed to save session: {ex.Message}");
        Console.ResetColor();
    }
}

static bool LoadState()
{
    try
    {
        if (!System.IO.File.Exists(SaveFilePath))
            return false;

        string json = System.IO.File.ReadAllText(SaveFilePath);
        var save = JsonSerializer.Deserialize<SaveData>(json);

        if (save == null)
            return false;

        // Clear existing state
        networkDevices.Clear();
        packageRepo.Clear();

        // Restore package repo
        foreach (var kvp in save.PackageRepo)
            packageRepo[kvp.Key] = kvp.Value;

        // Restore devices
        foreach (var kvp in save.Devices)
        {
            int port = int.Parse(kvp.Key);
            var devSave = kvp.Value;

            var device = new Device
            {
                Name = devSave.Name,
                Ports = new List<int>(devSave.Ports),
                ListeningPorts = new HashSet<int>(devSave.ListeningPorts),
                Folders = new Dictionary<string, List<string>>(),
                Files = new Dictionary<string, string>(devSave.Files),
                MessageQueue = new Queue<string>(devSave.MessageQueue)
            };

            foreach (var folder in devSave.Folders)
                device.Folders[folder.Key] = new List<string>(folder.Value);

            networkDevices[port] = device;
        }

        // Restore host device reference
        if (networkDevices.TryGetValue(save.HostPort, out var host))
        {
            hostDevice = host;
            hostPort = save.HostPort;
        }
        else
        {
            return false;
        }

        // Restore active device
        activeDevice = hostDevice;
        activeFolder = save.ActiveFolder ?? "C:/";
        currentConnectionPort = save.CurrentConnectionPort;
        currentConnectionName = save.CurrentConnectionName ?? "";

        // Verify active folder exists
        if (!activeDevice.Folders.ContainsKey(activeFolder))
            activeFolder = "C:/";

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Previous session restored.");
        Console.ResetColor();
        return true;
    }
    catch (Exception ex)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"Could not restore session: {ex.Message}");
        Console.WriteLine("Starting fresh...");
        Console.ResetColor();
        return false;
    }
}

        static void LoadPerms()
        {
            protectedFolders.Clear();
            lockedFiles.Clear();
            devicePasswords.Clear();

            if (!activeDevice.Files.TryGetValue(PermsPath, out var content) || string.IsNullOrEmpty(content))
                return;

            string currentSection = "";
            var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line == "" || line.StartsWith("#")) continue;

                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    currentSection = line.ToLower();
                    continue;
                }

                switch (currentSection)
                {
                    case "[protected_folders]":
                        var pf = line.Replace("\\", "/");
                        if (!pf.EndsWith("/")) pf += "/";
                        protectedFolders.Add(pf);
                        break;
                    case "[locked_files]":
                        var lf = line.Replace("\\", "/");
                        lockedFiles.Add(lf);
                        break;
                    case "[device_passwords]":
                        var kv = line.Split('=', 2);
                        if (kv.Length == 2)
                        {
                            var name = kv[0].Trim();
                            var pass = kv[1].Trim();
                            if (!string.IsNullOrEmpty(name))
                                devicePasswords[name] = pass;
                        }
                        break;
                }
            }
        }

        static void CommandLoop()
        {
            while (true)
            {
                Console.Write($"[{activeDevice.Name}@{(activeDevice.Ports.Count > 0 ? activeDevice.Ports[0].ToString() : "?")}] {activeFolder}> ");
                string input = Console.ReadLine() ?? "";

                string[] parts = input.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 0) continue;

                string command = parts[0];
                string arguments = parts.Length > 1 ? parts[1] : "";

                if (command == "help")              PrintHelp();
                else if (command == "cd")           CmdCd(arguments);
                else if (command == "ls")           CmdLs();
                else if (command == "mkdir")        CmdMkdir(arguments);
                else if (command == "mkfle")        CmdMkfle(arguments);
                else if (command == "rm")           CmdRm(arguments);
                else if (command == "cp")           CmdCp(arguments);
                else if (command == "nano")         CmdNano(arguments);
                else if (command == "open")         CmdOpen(arguments);
                else if (command == "remotelisten")  NetRemoteListen(arguments);
                else if (command == "closeport")    NetClosePort(arguments);
                else if (command == "print")
                {
                    if (arguments == "") Console.WriteLine("Incorrect usage of print. Usage: print <args>");
                    else Console.WriteLine(arguments);
                }
                else if (command == "cls" || command == "clear")
                {
                    Console.Clear();
                    Console.WriteLine($"AmityOS Kernel v.{OsVersion} loaded\n");
                    Console.WriteLine("For more information, type help\n");
                }
                else if (command == "unlist") CmdUnlist(arguments);
                else if (command == "shutdown")
                {
                SaveState();
                break;
                }


                // Package commands
                else if (command == "install")      CmdInstall(arguments);
                else if (command == "uninstall")    CmdUninstall(arguments);
                else if (command == "pkgbuild")     CmdPkgBuild(arguments);
                else if (command == "pkgedit")      CmdPkgEdit(arguments);
                else if (command == "pkghelp")      CmdPkgHelp();
                else if (command == "installpkg")   CmdInstallPkg(arguments);

                // Networking
                else if (command == "switch")
                {
                    if (arguments == "")
                        Console.WriteLine("Usage: switch <port>");
                    else if (!int.TryParse(arguments, out int port))
                        Console.WriteLine("Invalid port number.");
                    else if (!networkDevices.TryGetValue(port, out var dev))
                        Console.WriteLine("No device found on that port.");
                    else if (!dev.ListeningPorts.Contains(port))
                        Console.WriteLine($"Cannot switch: device '{dev.Name}' is not listening on port {port}.");
                    else if (currentConnectionPort != port)
                        Console.WriteLine($"Cannot switch: you are not connected to port {port}. Use connect {port} first.");
                    else
                    {
                        activeDevice = dev;
                        activeFolder = "C:/";
                        Console.WriteLine($"Switched to device '{dev.Name}' on port {port}.");
                    }
                }
                else if (command == "probe")        NetProbe();
                else if (command == "ping")         NetPing(arguments);
                else if (command == "connect")      NetConnect(arguments);
                else if (command == "mkdvc")        NetMkdvc(arguments);
                else if (command == "openport")     NetOpenPort(arguments);
                else if (command == "listen")       NetListen(arguments);
                else if (command == "send")         NetSend(arguments);
                else if (command == "recv")         NetRecv();
                else if (command == "check")        NetCheck(arguments);

                else Console.WriteLine("That command is not recognized. Type help for a list of commands.");
            }

            Console.WriteLine("AmityOS is shutting down...");
        }

static void NetClosePort(string arguments)
{
    if (!int.TryParse(arguments, out int port))
    {
        Console.WriteLine("Invalid port number.");
        return;
    }

    if (!activeDevice.Ports.Contains(port) && !activeDevice.ListeningPorts.Contains(port))
    {
        Console.WriteLine($"Port {port} is not open on this device.");
        return;
    }

    activeDevice.Ports.Remove(port);
    activeDevice.ListeningPorts.Remove(port);
    Console.WriteLine($"Closed port {port}.");
}

static void CmdUnlist(string arguments)
{
    if (string.IsNullOrEmpty(arguments))
    {
        Console.WriteLine("Usage: unlist <name>.pkg");
        return;
    }

    if (arguments == "*")
    {
        int count = packageRepo.Count;
        packageRepo.Clear();
        Console.WriteLine($"Removed all {count} packages from install list.");
        return;
    }

    if (!arguments.EndsWith(".pkg"))
    {
        Console.WriteLine("Package name must end with .pkg");
        return;
    }

    if (!packageRepo.ContainsKey(arguments))
    {
        Console.WriteLine($"'{arguments}' is not in the install list.");
        return;
    }

    packageRepo.Remove(arguments);
    Console.WriteLine($"Removed '{arguments}' from install list.");
}

static void NetRemoteListen(string arguments)
{
    var parts = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length < 2)
    {
        Console.WriteLine("Usage: remotelisten <device_port> <listen_port>");
        return;
    }

    if (!int.TryParse(parts[0], out int devicePort))
    {
        Console.WriteLine("Invalid device port number.");
        return;
    }

    if (!int.TryParse(parts[1], out int listenPort))
    {
        Console.WriteLine("Invalid listen port number.");
        return;
    }

    if (!networkDevices.TryGetValue(devicePort, out var device))
    {
        Console.WriteLine($"No device found on port {devicePort}.");
        return;
    }

    if (!device.Ports.Contains(listenPort))
        device.Ports.Add(listenPort);

    device.ListeningPorts.Add(listenPort);
    Console.WriteLine($"Device on port {devicePort} is now listening on port {listenPort}.");
}

        static void PrintHelp()
        {
            Console.WriteLine("AmityOS 2026");
            Console.WriteLine($"Version {OsVersion} ");
            Console.WriteLine("");
            Console.WriteLine("Available commands:");
            Console.WriteLine("  help                        - Shows this list");
            Console.WriteLine("  cd <folder>                 - Navigate to a directory");
            Console.WriteLine("  cd ..                       - Navigate to parent directory");
            Console.WriteLine("  ls                          - List all folders and files");
            Console.WriteLine("  mkdir <foldername>          - Create a mock-directory");
            Console.WriteLine("  mkfle <filename>            - Create a mock-file");
            Console.WriteLine("  rm <filename>               - Delete a file");
            Console.WriteLine("  rm *                        - Delete ALL files in current directory");
            Console.WriteLine("  print <args>                - Prints arguments to the console");
            Console.WriteLine("  cls                         - Clears the screen");
            Console.WriteLine("  shutdown                    - Shuts down AmityOS");
            Console.WriteLine("  open <filename>             - Opens and displays a file");
            Console.WriteLine("  cp <source> <destination>   - Copies a file");
            Console.WriteLine("  nano <filename>             - Simple text editor");
            Console.WriteLine("  install <name>.pkg          - Install a package into downloads");
            Console.WriteLine("  install list                - List all installable packages");
            Console.WriteLine("  uninstall <name>.pkg        - Remove a .pkg file");
            Console.WriteLine("  switch <port>               - Switch control to device on port");
            Console.WriteLine("  probe                       - Scan network for devices + ports");
            Console.WriteLine("  ping <port>                 - Test if a device is reachable");
            Console.WriteLine("  connect <port>              - Connect to device on that port");
            Console.WriteLine("  mkdvc <name> <port>         - Create a new mock device");
            Console.WriteLine("  openport <port>             - Open a port on the active device");
            Console.WriteLine("  listen <port>               - Begin listening on a port");
            Console.WriteLine("  send <msg>                  - Send data to connected device");
            Console.WriteLine("  recv                        - Receive data for active device");
            Console.WriteLine("  check <port>                - Show port status");
            Console.WriteLine("  pkgedit <name>.pkg          - Edit a .pkg file with the pkg editor");
            Console.WriteLine("  pkghelp                     - Displays the .pkgeditor documentation");
            Console.WriteLine("  remotelisten <devport> <listenport> - Make a device listen on a port");
            Console.WriteLine("  closeport <port>            - Close a port on the active device");
            Console.WriteLine("  unlist <name>.pkg           - Remove a package from the install list");
            Console.WriteLine("");
            Console.WriteLine("Note: AmityOS is not a real operating system. It cannot interact with your");
            Console.WriteLine("actual filesystem or network. All commands operate on a simulated environment.");
            Console.WriteLine($"AmityOS v{OsVersion} - Work in progress. Have fun experimenting!");
        }

        static void CmdPkgHelp()
        {
            Console.WriteLine("===========================================");
            Console.WriteLine("  AmityOS .pkg Editor Documentation");
            Console.WriteLine($"  Version {OsVersion}");
            Console.WriteLine("===========================================");
            Console.WriteLine("");
            Console.WriteLine("OVERVIEW");
            Console.WriteLine("  .pkg files are AmityOS packages. Use pkgedit <name>.pkg to edit them.");
            Console.WriteLine("  On save, the package is registered in the install list.");
            Console.WriteLine("");
            Console.WriteLine("--- DEFINITION ---");
            Console.WriteLine("  pkgname @<name>         - Define the package name");
            Console.WriteLine("  def $<var>              - Define a variable");
            Console.WriteLine("  setbool $<var>          - Define a boolean variable");
            Console.WriteLine("  bool $<var> = [true/false] - Set a boolean value");
            Console.WriteLine("  dfunc #<name>           - Define a function");
            Console.WriteLine("  endfunc                 - End a function definition");
            Console.WriteLine("");
            Console.WriteLine("--- LOGIC GATES AND CONDITIONALS ---");
            Console.WriteLine("  if <var>                - IF conditional");
            Console.WriteLine("  then, #<func>           - THEN action delimiter");
            Console.WriteLine("  <var> or <var> =        - OR logic gate");
            Console.WriteLine("  <var> and <var> =       - AND logic gate");
            Console.WriteLine("  <var> not =             - NOT logic gate");
            Console.WriteLine("");
            Console.WriteLine("--- OPERATORS ---");
            Console.WriteLine("  =                       - Equality operator");
            Console.WriteLine("  ,                       - Universal separator");
            Console.WriteLine("  -                       - Subtractor");
            Console.WriteLine("  +                       - Additioner");
            Console.WriteLine("  ;                       - End");
            Console.WriteLine("");
            Console.WriteLine("--- EXECUTION ---");
            Console.WriteLine("  call #<func>            - Call a function");
            Console.WriteLine("  rpcall #<func> <n> [*]  - Repeat-call a function N times");
            Console.WriteLine("  keycall #<func> <key>   - Call a function when key is pressed");
            Console.WriteLine("  end                     - End the .pkg");
            Console.WriteLine("");
            Console.WriteLine("--- EXECUTABLES (inside functions) ---");
            Console.WriteLine("  print <text>            - Output text");
            Console.WriteLine("  set $<var> <value>      - Assign value to variable");
            Console.WriteLine("  inc $<var>              - Increment numeric variable by 1");
            Console.WriteLine("  dec $<var>              - Decrement numeric variable by 1");
            Console.WriteLine("  wait <ms>               - Pause execution");
            Console.WriteLine("  exit                    - Stop current function");
            Console.WriteLine("  write <file> <text>     - Write text to file (overwrite)");
            Console.WriteLine("  append <file> <text>    - Append text to file");
            Console.WriteLine("  read <file>             - Display file contents");
            Console.WriteLine("  delete <file>           - Remove a file");
            Console.WriteLine("  exists <file>           - Check if file exists");
            Console.WriteLine("  input $<var>            - Read user input into variable");
            Console.WriteLine("  ask $<var> <question>   - Ask a question, store answer");
            Console.WriteLine("  confirm $<var> <q>      - Ask yes/no, store true/false");
            Console.WriteLine("  rnd $<var> <max>        - Generate random number");
            Console.WriteLine("  comp $<var> <a> <b>     - Compare two values");
            Console.WriteLine("  goto <label>            - Jump to label");
            Console.WriteLine("  label <name>            - Define a jump target");
            Console.WriteLine("  loop <n>                - Begin loop N times");
            Console.WriteLine("  endloop                 - End loop block");
            Console.WriteLine("  break                   - Exit current loop");
            Console.WriteLine("  continue                - Skip to next loop iteration");
            Console.WriteLine("  color <color>           - Change console text color");
            Console.WriteLine("  title <text>            - Set console window title");
            Console.WriteLine("  banner <text>           - Print stylized ASCII text");
            Console.WriteLine("  clear                   - Clear the screen");
            Console.WriteLine("  open <file>             - Open a file using AmityOS");
            Console.WriteLine("  copy <src> <dst>        - Copy a file");
            Console.WriteLine("  move <src> <dst>        - Move a file");
            Console.WriteLine("  rename <old> <new>      - Rename a file");
            Console.WriteLine("  length $<var> <str>     - Get string length");
            Console.WriteLine("  substring $<v> <s> <i> <n> - Extract substring");
            Console.WriteLine("  concat $<var> <a> <b>   - Combine two strings");
            Console.WriteLine("  toupper $<var> <str>    - Convert to uppercase");
            Console.WriteLine("  tolower $<var> <str>    - Convert to lowercase");
            Console.WriteLine("  reverse $<var> <str>    - Reverse a string");
            Console.WriteLine("  split <str> <delim>     - Split string into list");
            Console.WriteLine("  join $<var> <delim>     - Join list into string");
            Console.WriteLine("  push <value>            - Push value onto stack");
            Console.WriteLine("  pop $<var>              - Pop value from stack");
            Console.WriteLine("  peek $<var>             - Read top of stack");
            Console.WriteLine("  size $<var>             - Get size of list or stack");
            Console.WriteLine("  sort                    - Sort the list");
            Console.WriteLine("  shuffle                 - Shuffle the list");
            Console.WriteLine("  send <msg>              - Send data to connected device");
            Console.WriteLine("  recv $<var>             - Receive data into variable");
            Console.WriteLine("  connect <port>          - Connect to port");
            Console.WriteLine("  disconnect              - Disconnect from port");
            Console.WriteLine("  listen <port>           - Begin listening on port");
            Console.WriteLine("  openport <port>         - Open a port");
            Console.WriteLine("  closeport <port>        - Close a port");
            Console.WriteLine("  ping <port>             - Test if device is reachable");
            Console.WriteLine("  probe                   - Scan for devices and ports");
            Console.WriteLine("  device <name/port>      - Switch or query device info");
            Console.WriteLine("  time $<var>             - Get current time");
            Console.WriteLine("  date $<var>             - Get current date");
            Console.WriteLine("  timestamp $<var>        - Get current timestamp");
            Console.WriteLine("  sleep <ms>              - Alias for wait");
            Console.WriteLine("  flash <text>            - Flash text on screen");
            Console.WriteLine("  alert <text>            - Show alert message");
            Console.WriteLine("  notify <text>           - Show notification");
            Console.WriteLine("  error <text>            - Display error message");
            Console.WriteLine("  success <text>          - Display success message");
            Console.WriteLine("  warning <text>          - Display warning message");
            Console.WriteLine("  log <text>              - Write to system log");
            Console.WriteLine("  debug <text>            - Output debug information");
            Console.WriteLine("  trace <text>            - Output trace-level info");
            Console.WriteLine("  system <cmd>            - Run a system-level command");
            Console.WriteLine("  exec <pkg>              - Execute another .pkg file");
            Console.WriteLine("  run <cmd>               - Run a built-in OS command");
            Console.WriteLine("  spawn <func>            - Start a background task");
            Console.WriteLine("  kill <func>             - Stop a running task");
            Console.WriteLine("  restart                 - Restart the current .pkg");
            Console.WriteLine("  reboot                  - Reboot the OS (mock)");
            Console.WriteLine("  shutdown                - Shut down the OS");
            Console.WriteLine("  load $<var> <file>      - Load file data into variable");
            Console.WriteLine("  save <file> $<var>      - Save variable data to file");
            Console.WriteLine("  encrypt $<var> <text>   - Encrypt text");
            Console.WriteLine("  decrypt $<var> <text>   - Decrypt text");
            Console.WriteLine("  hash $<var> <text>      - Generate hash of text");
            Console.WriteLine("  version $<var>          - Get AmityOS version");
            Console.WriteLine("  pkginfo                 - Get metadata about running .pkg");
            Console.WriteLine("");
            Console.WriteLine("Once saved, the .pkg will be added to Downloads and the install list.");
        }

        static void CmdCd(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: cd <folder>"); return; }

            if (arguments == "..")
            {
                if (activeFolder == "C:/")
                {
                    Console.WriteLine("Already at root.");
                    return;
                }
                string trimmed = activeFolder.TrimEnd('/');
                int lastSlash = trimmed.LastIndexOf('/');
                if (lastSlash < 0)
                    activeFolder = "C:/";
                else
                    activeFolder = trimmed.Substring(0, lastSlash + 1);
                return;
            }

            if (arguments.StartsWith("C:/"))
            {
                string target = arguments.EndsWith("/") ? arguments : arguments + "/";
                if (activeDevice.Folders.ContainsKey(target))
                    activeFolder = target;
                else
                    Console.WriteLine("Folder not found.");
                return;
            }

            string rel = activeFolder + arguments + "/";
            if (activeDevice.Folders.ContainsKey(rel))
                activeFolder = rel;
            else
                Console.WriteLine("Folder not found.");
        }

        static void CmdLs()
        {
            if (!activeDevice.Folders.ContainsKey(activeFolder))
            {
                Console.WriteLine("Current folder does not exist.");
                return;
            }

            bool any = false;
            foreach (var f in activeDevice.Folders[activeFolder])
            {
                Console.WriteLine($"<DIR> {f}");
                any = true;
            }

            var fileList = activeDevice.Files.Keys
                .Where(f => f.StartsWith(activeFolder) && !f.Substring(activeFolder.Length).Contains('/'))
                .Select(f => f.Substring(activeFolder.Length))
                .Where(f => !string.IsNullOrEmpty(f))
                .ToList();

            foreach (var file in fileList)
            {
                Console.WriteLine(file);
                any = true;
            }

            if (!any) Console.WriteLine("(empty)");
        }

        static void CmdMkdir(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: mkdir <foldername>"); return; }

            foreach (var pf in protectedFolders)
            {
                if (activeFolder.StartsWith(pf))
                {
                    Console.WriteLine("Access denied: cannot modify protected folder.");
                    return;
                }
            }

            string newPath = activeFolder + arguments + "/";
            if (activeDevice.Folders.ContainsKey(newPath)) { Console.WriteLine("Folder already exists."); return; }
            activeDevice.Folders[activeFolder].Add(arguments);
            activeDevice.Folders[newPath] = new List<string>();
            Console.WriteLine($"Created folder '{arguments}'.");
        }

        static void CmdMkfle(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: mkfle <filename>"); return; }

            foreach (var pf in protectedFolders)
            {
                if (activeFolder.StartsWith(pf))
                {
                    Console.WriteLine("Access denied: cannot modify protected folder.");
                    return;
                }
            }

            string filePath = activeFolder + arguments;
            if (activeDevice.Files.ContainsKey(filePath)) { Console.WriteLine("File already exists."); return; }
            activeDevice.Files[filePath] = "";
            Console.WriteLine($"Created file '{arguments}'.");
        }

        static void CmdRm(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: rm <filename> OR rm *"); return; }

            if (arguments == "*")
            {
                var toDelete = activeDevice.Files.Keys.Where(f => f.StartsWith(activeFolder) && !f.Substring(activeFolder.Length).Contains('/')).ToList();
                foreach (var f in toDelete)
                {
                    if (IsPathProtected(f)) { Console.WriteLine($"Skipped protected file: {f}"); continue; }
                    activeDevice.Files.Remove(f);
                }
                Console.WriteLine("All deletable files deleted.");
                return;
            }

            string filePath = activeFolder + arguments;

            if (filePath.Equals(PermsPath, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Access denied: perms.cfg is protected.");
                return;
            }

            if (!activeDevice.Files.ContainsKey(filePath)) { Console.WriteLine("File not found."); return; }

            if (IsPathProtected(filePath))
            {
                Console.WriteLine("Access denied: file is protected or locked.");
                return;
            }

            activeDevice.Files.Remove(filePath);
            Console.WriteLine($"Deleted file '{arguments}'.");
        }

        static void CmdCp(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: cp <source> <destination>"); return; }
            string[] cpArgs = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (cpArgs.Length < 2) { Console.WriteLine("Usage: cp <source> <destination>"); return; }

            string source = activeFolder + cpArgs[0];
            string dest = activeFolder + cpArgs[1];

            if (!activeDevice.Files.ContainsKey(source)) { Console.WriteLine("Source file not found."); return; }

            foreach (var pf in protectedFolders)
            {
                if (dest.StartsWith(pf))
                {
                    Console.WriteLine("Access denied: cannot copy into protected folder.");
                    return;
                }
            }

            if (activeDevice.Files.ContainsKey(dest)) { Console.WriteLine("Destination file already exists."); return; }
            activeDevice.Files[dest] = activeDevice.Files[source];
            Console.WriteLine($"Copied '{cpArgs[0]}' to '{cpArgs[1]}'.");
        }

        static void CmdNano(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: nano <filename>"); return; }

            string ext = GetExtension(arguments);
            if (ext == ".pkg")
            {
                Console.WriteLine("Cannot edit .pkg files directly with nano. Use pkgedit instead.");
                return;
            }

            string filePath = activeFolder + arguments;
            LaunchNano(filePath);

            if (filePath.Equals(PermsPath, StringComparison.OrdinalIgnoreCase))
            {
                LoadPerms();
                Console.WriteLine("Permissions reloaded from perms.cfg.");
            }
        }

        static void CmdOpen(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: open <filename>"); return; }
            string filePath = activeFolder + arguments;
            if (!activeDevice.Files.ContainsKey(filePath)) { Console.WriteLine("File not found."); return; }
            string ext = GetExtension(arguments);

            if (ext == ".pkg")
            {
                RunPackage(filePath);
                return;
            }

            if (appHandlers.TryGetValue(ext, out var handler)) handler(filePath);
            else OpenTextFile(filePath);
        }

        static void CmdInstall(string arguments)
        {
            if (arguments == "")
            {
                Console.WriteLine("Usage: install <name>.pkg OR install list");
                return;
            }

            if (arguments == "list")
            {
                Console.WriteLine("Installable packages:");
                if (packageRepo.Count == 0) Console.WriteLine("  (none)");
                else foreach (var pkg in packageRepo.Keys) Console.WriteLine($"  - {pkg}");
                return;
            }

            if (!arguments.EndsWith(".pkg"))
            {
                Console.WriteLine("Package name must end with .pkg");
                return;
            }

            if (!packageRepo.TryGetValue(arguments, out var payload))
            {
                Console.WriteLine("That package is not in the install list.");
                return;
            }

            string downloadsPath = "C:/user/downloads/";
            EnsureDownloads(downloadsPath);

            string pkgPath = downloadsPath + arguments;
            if (!activeDevice.Files.ContainsKey(pkgPath))
            {
                activeDevice.Files[pkgPath] = payload;
                Console.WriteLine($"Installed '{arguments}' to downloads.");
            }
            else
            {
                Console.WriteLine($"'{arguments}' is already installed in downloads.");
            }
        }

        static void CmdUninstall(string arguments)
        {
            if (arguments == "")
            {
                Console.WriteLine("Usage: uninstall <name>.pkg");
                return;
            }

            if (!arguments.EndsWith(".pkg"))
            {
                Console.WriteLine("Package name must end with .pkg");
                return;
            }

            string foundKey = activeDevice.Files.Keys
                .FirstOrDefault(k => k.EndsWith("/" + arguments));

            if (foundKey == null)
            {
                Console.WriteLine("Package file not found on this device.");
                return;
            }

            if (foundKey.Equals(PermsPath, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Access denied.");
                return;
            }

            if (IsPathProtected(foundKey))
            {
                Console.WriteLine("Access denied: package file is protected or locked.");
                return;
            }

            activeDevice.Files.Remove(foundKey);
            Console.WriteLine($"Uninstalled '{arguments}' from {foundKey}.");
        }

        static void CmdPkgEdit(string arguments)
        {
            if (string.IsNullOrEmpty(arguments))
            {
                Console.WriteLine("Usage: pkgedit <name>.pkg");
                return;
            }

            if (!arguments.EndsWith(".pkg"))
            {
                Console.WriteLine("pkgedit only works with .pkg files.");
                return;
            }

            string filePath = activeFolder + arguments;

            string existing = "";
            if (activeDevice.Files.TryGetValue(filePath, out var ex))
                existing = ex;

            Console.WriteLine($"=== pkgeditor: {arguments} ===");
            Console.WriteLine("Type your .pkg script. Commands: :wq = save & exit, :q = exit without saving, :help = show pkghelp");
            Console.WriteLine("-----------------------------------------------");

            if (!string.IsNullOrEmpty(existing))
            {
                Console.WriteLine("[Existing content:]");
                Console.WriteLine(existing);
                Console.WriteLine("[End of existing content. Type new content below (will replace existing):]");
            }

            var sb = new StringBuilder();
            while (true)
            {
                string line = Console.ReadLine() ?? "";
                if (line == ":wq")
                {
                    string pkgSource = sb.ToString();
                    activeDevice.Files[filePath] = pkgSource;

                    string downloadsPath = "C:/user/downloads/";
                    EnsureDownloads(downloadsPath);
                    string dlPath = downloadsPath + arguments;
                    activeDevice.Files[dlPath] = pkgSource;
                    packageRepo[arguments] = pkgSource;

                    Console.WriteLine($"Saved '{arguments}' and registered in install list.");
                    break;
                }
                else if (line == ":q")
                {
                    Console.WriteLine("Exited without saving.");
                    break;
                }
                else if (line == ":help")
                {
                    CmdPkgHelp();
                }
                else
                {
                    sb.AppendLine(line);
                }
            }
        }

        static void CmdPkgBuild(string arguments)
        {
            if (string.IsNullOrEmpty(arguments))
            {
                Console.WriteLine("Usage: pkgbuild <script.bld>");
                return;
            }

            string scriptPath = activeFolder + arguments;
            if (!activeDevice.Files.ContainsKey(scriptPath))
            {
                Console.WriteLine("Build script not found.");
                return;
            }

            string script = activeDevice.Files[scriptPath];
            var result = ParseAndBuildBld(script, scriptPath);
            if (!result.success)
            {
                Console.WriteLine($"Build failed: {result.message}");
                return;
            }

            string outPath = result.pkg.OutFile;
            if (string.IsNullOrEmpty(outPath))
                outPath = $"{result.pkg.PkgName}-{result.pkg.Version}.pkg";

            string pkgText = SerializePkg(result.pkg);
            string pkgFilePath = activeFolder + outPath;
            activeDevice.Files[pkgFilePath] = pkgText;

            string downloadsPath = "C:/user/downloads/";
            EnsureDownloads(downloadsPath);
            activeDevice.Files[downloadsPath + outPath] = pkgText;
            packageRepo[outPath] = pkgText;

            Console.WriteLine($"Built package: {outPath}");
            Console.WriteLine($"Files included: {result.pkg.Files.Count}  Boxes: {result.pkg.Boxes.Count}");
        }

        static void CmdInstallPkg(string arguments)
        {
            if (string.IsNullOrEmpty(arguments)) { Console.WriteLine("Usage: installpkg <name>.pkg"); return; }
            string pkgPath = activeFolder + arguments;
            if (!activeDevice.Files.TryGetValue(pkgPath, out var pkgText)) { Console.WriteLine("File not found."); return; }
            packageRepo[arguments] = pkgText;
            Console.WriteLine($"Added '{arguments}' to installable packages.");
        }

        static void CmdRunBox(string arguments)
        {
            if (string.IsNullOrEmpty(arguments)) { Console.WriteLine("Usage: runbox <pkg> <BoxName>"); return; }
            var parts = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 2) { Console.WriteLine("Usage: runbox <pkg> <BoxName>"); return; }

            string pkgName = parts[0];
            string boxName = parts[1];

            if (!packageRepo.TryGetValue(pkgName, out var pkgText))
            {
                Console.WriteLine("Package not found in repo.");
                return;
            }

            var header = ExtractHeaderFromPkg(pkgText);
            if (header == null) { Console.WriteLine("Invalid package format."); return; }

            string boxPath = $"boxes/{boxName}.box";
            var fileContents = ExtractFilesFromPkg(pkgText);
            if (!fileContents.TryGetValue(boxPath, out var boxSource))
            {
                Console.WriteLine($"Box file '{boxPath}' not found in package payload.");
                return;
            }

            RunBoxInteractive(boxSource, boxName);
        }

        static void RunPackage(string path)
        {
            string filename = path.Substring(path.LastIndexOf('/') + 1);
            if (!activeDevice.Files.TryGetValue(path, out var pkgText))
            {
                Console.WriteLine("Package file not found.");
                return;
            }

            if (filename.Equals("hello.pkg", StringComparison.OrdinalIgnoreCase) && pkgText == "PRESET_HELLO_PAYLOAD")
            {
                Console.WriteLine("Hello World!");
                return;
            }

            var header = ExtractHeaderFromPkg(pkgText);
            if (header != null)
            {
                if (header.Value.TryGetProperty("entry", out var entryElem))
                {
                    var entry = entryElem.GetString();
                    if (!string.IsNullOrEmpty(entry))
                    {
                        var files = ExtractFilesFromPkg(pkgText);
                        if (files.TryGetValue(entry, out var entryContent))
                        {
                            RunPkgScript(entryContent, filename);
                            return;
                        }
                    }
                }
                Console.WriteLine($"Executed package: {filename} (no runnable entry found)");
                return;
            }

            RunPkgScript(pkgText, filename);
        }

        static void RunPkgScript(string source, string pkgFile)
        {
            var rt = new PkgRuntime();
            rt.PkgFile = pkgFile;

            var rawLines = source.Split('\n');
            var lines = new List<string>();

            foreach (var raw in rawLines)
                lines.Add(raw);

            rt.AllLines = lines;

            bool inFunc = false;
            string currentFunc = null;
            var funcLines = new Dictionary<string, List<string>>();

            for (int i = 0; i < lines.Count; i++)
            {
                var trimmed = lines[i].Trim();
                if (trimmed == "" || trimmed.StartsWith("#")) continue;

                if (trimmed.StartsWith("dfunc ", StringComparison.OrdinalIgnoreCase))
                {
                    var fname = trimmed.Substring(6).Trim().TrimStart('#').Trim();
                    currentFunc = fname;
                    inFunc = true;
                    funcLines[fname] = new List<string>();
                    continue;
                }

                if (inFunc)
                {
                    if (trimmed.Equals("endfunc", StringComparison.OrdinalIgnoreCase))
                    {
                        inFunc = false;
                        currentFunc = null;
                    }
                    else
                    {
                        funcLines[currentFunc].Add(trimmed);
                    }
                    continue;
                }

                if (trimmed.StartsWith("label ", StringComparison.OrdinalIgnoreCase))
                {
                    var lname = trimmed.Substring(6).Trim();
                    rt.Labels[lname] = i;
                }
            }

            rt.Functions = funcLines;

            int lineIdx = 0;
            while (lineIdx < lines.Count && !rt.ShouldExit)
            {
                var raw = lines[lineIdx];
                var trimmed = raw.Trim();
                lineIdx++;

                if (trimmed == "" || trimmed.StartsWith("#")) continue;

                if (trimmed.StartsWith("dfunc ", StringComparison.OrdinalIgnoreCase))
                {
                    while (lineIdx < lines.Count)
                    {
                        var skip = lines[lineIdx].Trim();
                        lineIdx++;
                        if (skip.Equals("endfunc", StringComparison.OrdinalIgnoreCase)) break;
                    }
                    continue;
                }

                ExecutePkgLine(trimmed, rt);

                if (rt.CurrentLine > 0)
                {
                    lineIdx = rt.CurrentLine;
                    rt.CurrentLine = 0;
                }
            }
        }

        static void ExecutePkgLine(string line, PkgRuntime rt)
        {
            if (string.IsNullOrEmpty(line) || line.StartsWith("#")) return;

            line = SubstitutePkgVars(line, rt);

            var tokens = TokenizePkg(line);
            if (tokens.Count == 0) return;

            string cmd = tokens[0].ToLower();
            string rest = tokens.Count > 1 ? string.Join(" ", tokens.Skip(1)) : "";

            switch (cmd)
            {
                case "pkgname":
                {
                    var n = rest.TrimStart('@').Trim().Trim('"');
                    rt.PkgName = n;
                    break;
                }
                case "def":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (!rt.Vars.ContainsKey(vname)) rt.Vars[vname] = "";
                    break;
                }
                case "setbool":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (!rt.Bools.ContainsKey(vname)) rt.Bools[vname] = false;
                    break;
                }
                case "bool":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s*=\s*(true|false)$", RegexOptions.IgnoreCase);
                    if (m.Success)
                    {
                        rt.Bools[m.Groups[1].Value] = m.Groups[2].Value.ToLower() == "true";
                    }
                    break;
                }
                case "dfunc":
                case "endfunc":
                    break;

                case "call":
                {
                    var fname = rest.TrimStart('#').Trim();
                    CallPkgFunction(fname, rt);
                    break;
                }
                case "rpcall":
                {
                    var m = Regex.Match(rest, @"^#?(\w+)\s+(\d+)");
                    if (m.Success)
                    {
                        var fname = m.Groups[1].Value;
                        int count = int.Parse(m.Groups[2].Value);
                        for (int i = 0; i < count && !rt.ShouldExit; i++)
                            CallPkgFunction(fname, rt);
                    }
                    else Console.WriteLine($"[pkg] rpcall: invalid syntax '{rest}'");
                    break;
                }
                case "keycall":
                {
                    var m = Regex.Match(rest, @"^#?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var fname = m.Groups[1].Value;
                        var key = m.Groups[2].Value.Trim().Trim('"');
                        Console.Write($"[Press '{key}' to continue...] ");
                        string pressed = Console.ReadLine() ?? "";
                        if (pressed.Equals(key, StringComparison.OrdinalIgnoreCase))
                            CallPkgFunction(fname, rt);
                    }
                    break;
                }
                case "end":
                    rt.ShouldExit = true;
                    break;

                case "if":
                {
                    var ifMatch = Regex.Match(rest,
                        @"^\$?(\w+)\s*(==|!=|>|<|>=|<=)?\s*(.*?)\s*then,\s*#(\w+)$",
                        RegexOptions.IgnoreCase);
                    if (ifMatch.Success)
                    {
                        var vname = ifMatch.Groups[1].Value;
                        var op    = ifMatch.Groups[2].Value;
                        var rval  = ifMatch.Groups[3].Value.Trim().Trim('"');
                        var func  = ifMatch.Groups[4].Value;

                        bool condition = EvaluatePkgCondition(vname, op, rval, rt);
                        if (condition) CallPkgFunction(func, rt);
                    }
                    else
                    {
                        var simple = Regex.Match(rest, @"^\$?(\w+)\s+then,\s*#(\w+)$", RegexOptions.IgnoreCase);
                        if (simple.Success)
                        {
                            var vname = simple.Groups[1].Value;
                            var func  = simple.Groups[2].Value;
                            bool truthy = rt.Vars.TryGetValue(vname, out var val) && val != "" && val != "0" && val.ToLower() != "false";
                            if (!truthy && rt.Bools.TryGetValue(vname, out var bval)) truthy = bval;
                            if (truthy) CallPkgFunction(func, rt);
                        }
                        else Console.WriteLine($"[pkg] Invalid if syntax: {rest}");
                    }
                    break;
                }

                case "label":
                    break;
                case "goto":
                {
                    var lname = rest.Trim();
                    if (rt.Labels.TryGetValue(lname, out int target))
                        rt.CurrentLine = target;
                    else
                        Console.WriteLine($"[pkg] goto: label '{lname}' not found.");
                    break;
                }

                default:
                    ExecutePkgExecutable(cmd, rest, rt);
                    break;
            }
        }

        static void CallPkgFunction(string fname, PkgRuntime rt)
        {
            if (!rt.Functions.TryGetValue(fname, out var funcLines))
            {
                Console.WriteLine($"[pkg] Function '{fname}' not defined.");
                return;
            }

            int i = 0;
            var loopStack = new Stack<(int startIdx, int remaining)>();

            while (i < funcLines.Count && !rt.ShouldExit)
            {
                string raw = funcLines[i].Trim();
                i++;
                if (raw == "" || raw.StartsWith("#")) continue;

                raw = SubstitutePkgVars(raw, rt);
                var tokens = TokenizePkg(raw);
                if (tokens.Count == 0) continue;

                string cmd = tokens[0].ToLower();
                string rest = tokens.Count > 1 ? string.Join(" ", tokens.Skip(1)) : "";

                if (cmd == "exit")
                    break;

                if (cmd == "loop")
                {
                    if (int.TryParse(rest.Trim(), out int count))
                        loopStack.Push((i, count));
                    else
                        Console.WriteLine($"[pkg] loop: invalid count '{rest}'");
                    continue;
                }

                if (cmd == "endloop")
                {
                    if (loopStack.Count > 0)
                    {
                        var (startIdx, remaining) = loopStack.Pop();
                        if (remaining > 1)
                        {
                            loopStack.Push((startIdx, remaining - 1));
                            i = startIdx;
                        }
                    }
                    continue;
                }

                if (cmd == "break")
                {
                    if (loopStack.Count > 0)
                    {
                        loopStack.Pop();
                        int depth = 1;
                        while (i < funcLines.Count && depth > 0)
                        {
                            var skip = funcLines[i].Trim().ToLower();
                            if (skip == "loop") depth++;
                            if (skip == "endloop") depth--;
                            i++;
                        }
                    }
                    continue;
                }

                if (cmd == "continue")
                {
                    if (loopStack.Count > 0)
                    {
                        var (startIdx, remaining) = loopStack.Pop();
                        if (remaining > 1)
                        {
                            loopStack.Push((startIdx, remaining - 1));
                            i = startIdx;
                        }
                    }
                    continue;
                }

                if (cmd == "label")
                {
                    var lname = rest.Trim();
                    rt.Labels[$"{fname}::{lname}"] = i;
                    continue;
                }

                if (cmd == "goto")
                {
                    var lname = rest.Trim();
                    string key = $"{fname}::{lname}";
                    if (rt.Labels.TryGetValue(key, out int target))
                        i = target;
                    else
                        Console.WriteLine($"[pkg] goto: label '{lname}' not found in function '{fname}'.");
                    continue;
                }

                if (cmd == "if")
                {
                    var ifMatch = Regex.Match(rest,
                        @"^\$?(\w+)\s*(==|!=|>|<|>=|<=)?\s*(.*?)\s*then,\s*#(\w+)$",
                        RegexOptions.IgnoreCase);
                    if (ifMatch.Success)
                    {
                        var vname = ifMatch.Groups[1].Value;
                        var op    = ifMatch.Groups[2].Value;
                        var rval  = ifMatch.Groups[3].Value.Trim().Trim('"');
                        var func  = ifMatch.Groups[4].Value;
                        bool cond = EvaluatePkgCondition(vname, op, rval, rt);
                        if (cond) CallPkgFunction(func, rt);
                    }
                    else
                    {
                        var simple = Regex.Match(rest, @"^\$?(\w+)\s+then,\s*#(\w+)$", RegexOptions.IgnoreCase);
                        if (simple.Success)
                        {
                            var vname = simple.Groups[1].Value;
                            var func  = simple.Groups[2].Value;
                            bool truthy = rt.Vars.TryGetValue(vname, out var val) && val != "" && val != "0" && val.ToLower() != "false";
                            if (!truthy && rt.Bools.TryGetValue(vname, out var bval)) truthy = bval;
                            if (truthy) CallPkgFunction(func, rt);
                        }
                    }
                    continue;
                }

                if (cmd == "call") { CallPkgFunction(rest.TrimStart('#').Trim(), rt); continue; }
                if (cmd == "rpcall")
                {
                    var m = Regex.Match(rest, @"^#?(\w+)\s+(\d+)");
                    if (m.Success)
                    {
                        int count = int.Parse(m.Groups[2].Value);
                        for (int r = 0; r < count && !rt.ShouldExit; r++)
                            CallPkgFunction(m.Groups[1].Value, rt);
                    }
                    continue;
                }

                ExecutePkgExecutable(cmd, rest, rt);
            }
        }

        static void ExecutePkgExecutable(string cmd, string rest, PkgRuntime rt)
        {
            switch (cmd)
            {
                case "print":
                    Console.WriteLine(UnquotePkg(rest));
                    break;

                case "banner":
                {
                    var text = UnquotePkg(rest);
                    Console.WriteLine("*** " + text + " ***");
                    break;
                }

                case "alert":
                    Console.WriteLine($"[ALERT] {UnquotePkg(rest)}");
                    break;

                case "notify":
                    Console.WriteLine($"[NOTIFY] {UnquotePkg(rest)}");
                    break;

                case "error":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[ERROR] {UnquotePkg(rest)}");
                    Console.ResetColor();
                    break;

                case "success":
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"[SUCCESS] {UnquotePkg(rest)}");
                    Console.ResetColor();
                    break;

                case "warning":
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"[WARNING] {UnquotePkg(rest)}");
                    Console.ResetColor();
                    break;

                case "log":
                {
                    var msg = UnquotePkg(rest);
                    string logPath = "C:/os/system.log";
                    string entry = $"[{DateTime.Now:HH:mm:ss}] {msg}\n";
                    if (activeDevice.Files.ContainsKey(logPath))
                        activeDevice.Files[logPath] += entry;
                    else
                        activeDevice.Files[logPath] = entry;
                    Console.WriteLine($"[LOG] {msg}");
                    break;
                }

                case "debug":
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"[DEBUG] {UnquotePkg(rest)}");
                    Console.ResetColor();
                    break;

                case "trace":
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine($"[TRACE] {UnquotePkg(rest)}");
                    Console.ResetColor();
                    break;

                case "clear":
                    Console.Clear();
                    Console.WriteLine($"AmityOS Kernel v.{OsVersion} loaded\n");
                    break;

                case "title":
                    Console.Title = UnquotePkg(rest);
                    break;

                case "color":
                {
                    var colorName = UnquotePkg(rest).ToLower();
                    if (Enum.TryParse<ConsoleColor>(colorName, true, out var color))
                        Console.ForegroundColor = color;
                    else
                        Console.WriteLine($"[pkg] Unknown color: {colorName}");
                    break;
                }

                case "flash":
                {
                    var text = UnquotePkg(rest);
                    for (int f = 0; f < 3; f++)
                    {
                        Console.Write(text);
                        System.Threading.Thread.Sleep(200);
                        int back = text.Length;
                        Console.Write(new string('\b', back) + new string(' ', back) + new string('\b', back));
                        System.Threading.Thread.Sleep(200);
                    }
                    Console.WriteLine(text);
                    break;
                }

                case "set":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                        rt.Vars[m.Groups[1].Value] = UnquotePkg(m.Groups[2].Value);
                    else
                    {
                        var vm = Regex.Match(rest, @"^\$?(\w+)$");
                        if (vm.Success) rt.Vars[vm.Groups[1].Value] = "";
                        else Console.WriteLine($"[pkg] set: invalid syntax '{rest}'");
                    }
                    break;
                }

                case "inc":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (rt.Vars.TryGetValue(vname, out var v) && double.TryParse(v, out double d))
                        rt.Vars[vname] = (d + 1).ToString();
                    else
                        rt.Vars[vname] = "1";
                    break;
                }

                case "dec":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (rt.Vars.TryGetValue(vname, out var v) && double.TryParse(v, out double d))
                        rt.Vars[vname] = (d - 1).ToString();
                    else
                        rt.Vars[vname] = "-1";
                    break;
                }

                case "wait":
                case "sleep":
                {
                    if (int.TryParse(rest.Trim(), out int ms))
                        System.Threading.Thread.Sleep(ms);
                    else
                        Console.WriteLine($"[pkg] wait/sleep: invalid milliseconds '{rest}'");
                    break;
                }

                case "input":
                {
                    var vname = rest.TrimStart('$').Trim();
                    Console.Write("> ");
                    var val = Console.ReadLine() ?? "";
                    rt.Vars[vname] = val;
                    break;
                }

                case "ask":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        Console.Write(UnquotePkg(m.Groups[2].Value) + " ");
                        rt.Vars[m.Groups[1].Value] = Console.ReadLine() ?? "";
                    }
                    else Console.WriteLine($"[pkg] ask: invalid syntax '{rest}'");
                    break;
                }

                case "confirm":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        Console.Write(UnquotePkg(m.Groups[2].Value) + " [y/n] ");
                        var ans = (Console.ReadLine() ?? "").Trim().ToLower();
                        rt.Vars[m.Groups[1].Value] = (ans == "y" || ans == "yes") ? "true" : "false";
                        rt.Bools[m.Groups[1].Value] = ans == "y" || ans == "yes";
                    }
                    else Console.WriteLine($"[pkg] confirm: invalid syntax '{rest}'");
                    break;
                }

                case "write":
                {
                    var m = Regex.Match(rest, @"^(\S+)\s+(.+)$");
                    if (m.Success)
                    {
                        var fp = ResolveActivePath(m.Groups[1].Value);
                        activeDevice.Files[fp] = UnquotePkg(m.Groups[2].Value) + "\n";
                    }
                    else Console.WriteLine($"[pkg] write: invalid syntax '{rest}'");
                    break;
                }

                case "append":
                {
                    var m = Regex.Match(rest, @"^(\S+)\s+(.+)$");
                    if (m.Success)
                    {
                        var fp = ResolveActivePath(m.Groups[1].Value);
                        string existing2 = activeDevice.Files.TryGetValue(fp, out var ex) ? ex : "";
                        activeDevice.Files[fp] = existing2 + UnquotePkg(m.Groups[2].Value) + "\n";
                    }
                    else Console.WriteLine($"[pkg] append: invalid syntax '{rest}'");
                    break;
                }

                case "read":
                {
                    var fp = ResolveActivePath(rest.Trim());
                    if (activeDevice.Files.TryGetValue(fp, out var content))
                        Console.WriteLine(content);
                    else
                        Console.WriteLine($"[pkg] read: file not found '{fp}'");
                    break;
                }

                case "delete":
                {
                    var fp = ResolveActivePath(rest.Trim());
                    if (activeDevice.Files.ContainsKey(fp))
                    {
                        if (!IsPathProtected(fp)) activeDevice.Files.Remove(fp);
                        else Console.WriteLine("[pkg] delete: file is protected.");
                    }
                    else Console.WriteLine($"[pkg] delete: file not found '{fp}'");
                    break;
                }

                case "exists":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var fp = ResolveActivePath(m.Groups[2].Value.Trim());
                        bool ex = activeDevice.Files.ContainsKey(fp);
                        rt.Vars[m.Groups[1].Value] = ex ? "true" : "false";
                        rt.Bools[m.Groups[1].Value] = ex;
                    }
                    else
                    {
                        var fp = ResolveActivePath(rest.Trim());
                        bool ex = activeDevice.Files.ContainsKey(fp);
                        Console.WriteLine($"File '{fp}': {(ex ? "exists" : "not found")}");
                    }
                    break;
                }

                case "open":
                {
                    var fp = ResolveActivePath(rest.Trim());
                    CmdOpen(fp.Substring(fp.LastIndexOf('/') + 1));
                    break;
                }

                case "copy":
                {
                    var m = Regex.Match(rest, @"^(\S+)\s+(.+)$");
                    if (m.Success)
                    {
                        var src = ResolveActivePath(m.Groups[1].Value.Trim());
                        var dst = ResolveActivePath(m.Groups[2].Value.Trim());
                        if (activeDevice.Files.TryGetValue(src, out var c))
                            activeDevice.Files[dst] = c;
                        else Console.WriteLine($"[pkg] copy: source not found '{src}'");
                    }
                    break;
                }

                case "move":
                {
                    var m = Regex.Match(rest, @"^(\S+)\s+(.+)$");
                    if (m.Success)
                    {
                        var src = ResolveActivePath(m.Groups[1].Value.Trim());
                        var dst = ResolveActivePath(m.Groups[2].Value.Trim());
                        if (activeDevice.Files.TryGetValue(src, out var c))
                        {
                            activeDevice.Files[dst] = c;
                            activeDevice.Files.Remove(src);
                        }
                        else Console.WriteLine($"[pkg] move: source not found '{src}'");
                    }
                    break;
                }

                case "rename":
                {
                    var m = Regex.Match(rest, @"^(\S+)\s+(.+)$");
                    if (m.Success)
                    {
                        var src = ResolveActivePath(m.Groups[1].Value.Trim());
                        var dst = ResolveActivePath(m.Groups[2].Value.Trim());
                        if (activeDevice.Files.TryGetValue(src, out var c))
                        {
                            activeDevice.Files[dst] = c;
                            activeDevice.Files.Remove(src);
                        }
                        else Console.WriteLine($"[pkg] rename: file not found '{src}'");
                    }
                    break;
                }

                case "load":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var fp = ResolveActivePath(m.Groups[2].Value.Trim());
                        rt.Vars[m.Groups[1].Value] = activeDevice.Files.TryGetValue(fp, out var c) ? c : "";
                    }
                    break;
                }

                case "save":
                {
                    var m = Regex.Match(rest, @"^(\S+)\s+\$?(\w+)$");
                    if (m.Success)
                    {
                        var fp = ResolveActivePath(m.Groups[1].Value.Trim());
                        var val = rt.Vars.TryGetValue(m.Groups[2].Value, out var v) ? v : "";
                        activeDevice.Files[fp] = val;
                    }
                    break;
                }

                case "length":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var str = UnquotePkg(m.Groups[2].Value);
                        rt.Vars[m.Groups[1].Value] = str.Length.ToString();
                    }
                    break;
                }

                case "substring":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(\S+)\s+(\d+)\s+(\d+)$");
                    if (m.Success)
                    {
                        var str = UnquotePkg(m.Groups[2].Value);
                        int idx = int.Parse(m.Groups[3].Value);
                        int len = int.Parse(m.Groups[4].Value);
                        if (idx >= 0 && idx < str.Length)
                            rt.Vars[m.Groups[1].Value] = str.Substring(idx, Math.Min(len, str.Length - idx));
                        else
                            rt.Vars[m.Groups[1].Value] = "";
                    }
                    break;
                }

                case "concat":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+?)\s+(.+)$");
                    if (m.Success)
                    {
                        var s1 = UnquotePkg(m.Groups[2].Value);
                        var s2 = UnquotePkg(m.Groups[3].Value);
                        rt.Vars[m.Groups[1].Value] = s1 + s2;
                    }
                    break;
                }

                case "toupper":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var str = UnquotePkg(m.Groups[2].Value);
                        rt.Vars[m.Groups[1].Value] = str.ToUpper();
                    }
                    break;
                }

                case "tolower":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var str = UnquotePkg(m.Groups[2].Value);
                        rt.Vars[m.Groups[1].Value] = str.ToLower();
                    }
                    break;
                }

                case "reverse":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var str = UnquotePkg(m.Groups[2].Value);
                        var charArray = str.ToCharArray();
                        System.Array.Reverse(charArray);
                        rt.Vars[m.Groups[1].Value] = new string(charArray);
                    }
                    break;
                }

                case "split":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+?)\s+(.+)$");
                    if (m.Success)
                    {
                        var str = UnquotePkg(m.Groups[2].Value);
                        var delim = UnquotePkg(m.Groups[3].Value);
                        var parts = str.Split(new[] { delim }, StringSplitOptions.None);
                        rt.List = new List<string>(parts);
                    }
                    break;
                }

                case "join":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var delim = UnquotePkg(m.Groups[2].Value);
                        rt.Vars[m.Groups[1].Value] = string.Join(delim, rt.List);
                    }
                    break;
                }

                case "push":
                {
                    var val = UnquotePkg(rest);
                    rt.Stack.Push(val);
                    break;
                }

                case "pop":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (rt.Stack.Count > 0)
                        rt.Vars[vname] = rt.Stack.Pop();
                    else
                        Console.WriteLine("[pkg] pop: stack is empty");
                    break;
                }

                case "peek":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (rt.Stack.Count > 0)
                        rt.Vars[vname] = rt.Stack.Peek();
                    else
                        Console.WriteLine("[pkg] peek: stack is empty");
                    break;
                }

                case "size":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)(?:\s+(\S+))?$");
                    if (m.Success)
                    {
                        var target = m.Groups[2].Value.ToLower();
                        int sz = target == "stack" ? rt.Stack.Count : rt.List.Count;
                        rt.Vars[m.Groups[1].Value] = sz.ToString();
                    }
                    break;
                }

                case "sort":
                    rt.List.Sort();
                    Console.WriteLine("[pkg] List sorted.");
                    break;

                case "shuffle":
                {
                    var rnd = new Random();
                    for (int i = rt.List.Count - 1; i > 0; i--)
                    {
                        int j = rnd.Next(i + 1);
                        var temp = rt.List[i];
                        rt.List[i] = rt.List[j];
                        rt.List[j] = temp;
                    }
                    Console.WriteLine("[pkg] List shuffled.");
                    break;
                }

                case "rnd":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(\d+)$");
                    if (m.Success)
                    {
                        int max = int.Parse(m.Groups[2].Value);
                        int rndVal = new Random().Next(max + 1);
                        rt.Vars[m.Groups[1].Value] = rndVal.ToString();
                    }
                    break;
                }

                case "comp":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+?)\s+(.+)$");
                    if (m.Success)
                    {
                        var v1 = UnquotePkg(m.Groups[2].Value);
                        var v2 = UnquotePkg(m.Groups[3].Value);
                        int cmp = v1.CompareTo(v2);
                        rt.Vars[m.Groups[1].Value] = cmp.ToString();
                    }
                    break;
                }

                case "time":
                {
                    var vname = rest.TrimStart('$').Trim();
                    rt.Vars[vname] = DateTime.Now.ToString("HH:mm:ss");
                    break;
                }

                case "date":
                {
                    var vname = rest.TrimStart('$').Trim();
                    rt.Vars[vname] = DateTime.Now.ToString("yyyy-MM-dd");
                    break;
                }

                case "timestamp":
                {
                    var vname = rest.TrimStart('$').Trim();
                    rt.Vars[vname] = DateTime.Now.Ticks.ToString();
                    break;
                }

                case "encrypt":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var text = UnquotePkg(m.Groups[2].Value);
                        var encrypted = Convert.ToBase64String(Encoding.UTF8.GetBytes(text));
                        rt.Vars[m.Groups[1].Value] = encrypted;
                    }
                    break;
                }

                case "decrypt":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        try
                        {
                            var text = UnquotePkg(m.Groups[2].Value);
                            var decrypted = Encoding.UTF8.GetString(Convert.FromBase64String(text));
                            rt.Vars[m.Groups[1].Value] = decrypted;
                        }
                        catch
                        {
                            rt.Vars[m.Groups[1].Value] = "(invalid)";
                        }
                    }
                    break;
                }

                case "hash":
                {
                    var m = Regex.Match(rest, @"^\$?(\w+)\s+(.+)$");
                    if (m.Success)
                    {
                        var text = UnquotePkg(m.Groups[2].Value);
                        using (var sha = System.Security.Cryptography.SHA256.Create())
                        {
                            var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(text));
                            rt.Vars[m.Groups[1].Value] = Convert.ToHexString(hash);
                        }
                    }
                    break;
                }

                case "version":
                {
                    var vname = rest.TrimStart('$').Trim();
                    rt.Vars[vname] = OsVersion;
                    break;
                }

                case "pkginfo":
                {
                    Console.WriteLine($"Package: {rt.PkgName}");
                    Console.WriteLine($"Version: {rt.PkgVersion}");
                    Console.WriteLine($"File: {rt.PkgFile}");
                    break;
                }

                case "connect":
                {
                    if (int.TryParse(rest.Trim(), out int port))
                        NetConnect(rest.Trim());
                    else
                        Console.WriteLine($"[pkg] connect: invalid port '{rest}'");
                    break;
                }

                case "disconnect":
                {
                    currentConnectionPort = 0;
                    currentConnectionName = "";
                    Console.WriteLine("[pkg] Disconnected.");
                    break;
                }

                case "listen":
                {
                    if (int.TryParse(rest.Trim(), out int port))
                        NetListen(rest.Trim());
                    else
                        Console.WriteLine($"[pkg] listen: invalid port '{rest}'");
                    break;
                }

                case "openport":
                {
                    if (int.TryParse(rest.Trim(), out int port))
                        NetOpenPort(rest.Trim());
                    else
                        Console.WriteLine($"[pkg] openport: invalid port '{rest}'");
                    break;
                }

                case "closeport":
                {
                    if (int.TryParse(rest.Trim(), out int port))
                    {
                        if (activeDevice.Ports.Contains(port))
                            activeDevice.Ports.Remove(port);
                        activeDevice.ListeningPorts.Remove(port);
                        Console.WriteLine($"[pkg] Closed port {port}.");
                    }
                    break;
                }

                case "ping":
                {
                    if (int.TryParse(rest.Trim(), out int port))
                        NetPing(rest.Trim());
                    else
                        Console.WriteLine($"[pkg] ping: invalid port '{rest}'");
                    break;
                }

                case "probe":
                {
                    NetProbe();
                    break;
                }

                case "send":
                {
                    var msg = UnquotePkg(rest);
                    NetSend(msg);
                    break;
                }

                case "recv":
                {
                    var vname = rest.TrimStart('$').Trim();
                    if (currentConnectionPort > 0 && networkDevices.TryGetValue(currentConnectionPort, out var dev))
                    {
                        if (dev.MessageQueue.Count > 0)
                            rt.Vars[vname] = dev.MessageQueue.Dequeue();
                        else
                            rt.Vars[vname] = "";
                    }
                    else
                        rt.Vars[vname] = "";
                    break;
                }

                case "device":
                {
                    var arg = rest.Trim();
                    if (int.TryParse(arg, out int port))
                    {
                        if (networkDevices.TryGetValue(port, out var dev))
                            Console.WriteLine($"Device '{dev.Name}' on port {port}");
                        else
                            Console.WriteLine("No device on that port.");
                    }
                    else
                    {
                        Console.WriteLine($"Active device: {activeDevice.Name}");
                    }
                    break;
                }

                case "system":
                case "run":
                case "exec":
                case "spawn":
                case "kill":
                case "restart":
                case "reboot":
                {
                    Console.WriteLine($"[pkg] '{cmd}' is reserved/not yet implemented.");
                    break;
                }

                default:
                    Console.WriteLine($"[pkg] Unknown executable: {cmd}");
                    break;
            }
        }

        static bool EvaluatePkgCondition(string varName, string op, string rval, PkgRuntime rt)
        {
            string lval = "";
            if (rt.Vars.TryGetValue(varName, out var v)) lval = v;
            else if (rt.Bools.TryGetValue(varName, out var b)) lval = b ? "true" : "false";

            if (string.IsNullOrEmpty(op))
            {
                return lval != "" && lval != "0" && lval.ToLower() != "false";
            }

            if (double.TryParse(lval, out double ld) && double.TryParse(rval, out double rd))
            {
                return op switch
                {
                    "==" => ld == rd,
                    "!=" => ld != rd,
                    ">" => ld > rd,
                    "<" => ld < rd,
                    ">=" => ld >= rd,
                    "<=" => ld <= rd,
                    _ => false
                };
            }

            return op switch
            {
                "==" => lval == rval,
                "!=" => lval != rval,
                ">" => string.Compare(lval, rval) > 0,
                "<" => string.Compare(lval, rval) < 0,
                ">=" => string.Compare(lval, rval) >= 0,
                "<=" => string.Compare(lval, rval) <= 0,
                _ => false
            };
        }

        static string SubstitutePkgVars(string line, PkgRuntime rt)
        {
            var regex = new Regex(@"\$\{?(\w+)\}?");
            return regex.Replace(line, m =>
            {
                string varName = m.Groups[1].Value;
                if (rt.Vars.TryGetValue(varName, out var val)) return val;
                if (rt.Bools.TryGetValue(varName, out var bval)) return bval ? "true" : "false";
                return m.Value;
            });
        }

        static List<string> TokenizePkg(string line)
        {
            var tokens = new List<string>();
            var sb = new StringBuilder();
            bool inQuote = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    inQuote = !inQuote;
                    sb.Append(c);
                }
                else if (!inQuote && char.IsWhiteSpace(c))
                {
                    if (sb.Length > 0)
                    {
                        tokens.Add(sb.ToString());
                        sb.Clear();
                    }
                }
                else
                {
                    sb.Append(c);
                }
            }
            if (sb.Length > 0) tokens.Add(sb.ToString());
            return tokens;
        }

        static string UnquotePkg(string s)
        {
            if (s.StartsWith("\"") && s.EndsWith("\""))
                return s.Substring(1, s.Length - 2);
            return s;
        }

        static string ResolveActivePath(string path)
        {
            if (path.StartsWith("C:/"))
                return path.EndsWith("/") ? path : path + "/";
            return (activeFolder + path).Replace("//", "/");
        }

        static void NetProbe()
        {
            Console.WriteLine("=== Network Probe ===");
            foreach (var kvp in networkDevices)
            {
                var dev = kvp.Value;
                Console.WriteLine($"Port {kvp.Key}: Device '{dev.Name}'");
                Console.WriteLine($"  Open ports: {string.Join(", ", dev.Ports)}");
                Console.WriteLine($"  Listening: {string.Join(", ", dev.ListeningPorts)}");
            }
        }

        static void NetPing(string arguments)
        {
            if (!int.TryParse(arguments, out int port))
            {
                Console.WriteLine("Invalid port number.");
                return;
            }

            if (networkDevices.TryGetValue(port, out var dev))
                Console.WriteLine($"Ping to port {port} ('{dev.Name}'): OK");
            else
                Console.WriteLine($"Ping to port {port}: UNREACHABLE");
        }

        static void NetConnect(string arguments)
        {
            if (!int.TryParse(arguments, out int port))
            {
                Console.WriteLine("Invalid port number.");
                return;
            }

            if (!networkDevices.TryGetValue(port, out var dev))
            {
                Console.WriteLine("No device found on that port.");
                return;
            }

            if (!dev.ListeningPorts.Contains(port))
            {
                Console.WriteLine($"Device '{dev.Name}' is not listening on port {port}.");
                return;
            }

            currentConnectionPort = port;
            currentConnectionName = dev.Name;
            Console.WriteLine($"Connected to port {port} (device '{dev.Name}').");
        }

        static void NetMkdvc(string arguments)
        {
            var parts = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 2)
            {
                Console.WriteLine("Usage: mkdvc <name> <port>");
                return;
            }

            string name = parts[0];
            if (!int.TryParse(parts[1], out int port))
            {
                Console.WriteLine("Invalid port number.");
                return;
            }

            if (networkDevices.ContainsKey(port))
            {
                Console.WriteLine("Port already in use.");
                return;
            }

            var newDev = new Device
            {
                Name = name,
                Ports = new List<int> { port },
                ListeningPorts = new HashSet<int>(),
                Folders = new Dictionary<string, List<string>>
                {
                    { "C:/", new List<string>() }
                },
                Files = new Dictionary<string, string>()
            };

            networkDevices[port] = newDev;
            Console.WriteLine($"Created device '{name}' on port {port}.");
        }

        static void NetOpenPort(string arguments)
        {
            if (!int.TryParse(arguments, out int port))
            {
                Console.WriteLine("Invalid port number.");
                return;
            }

            if (!activeDevice.Ports.Contains(port))
                activeDevice.Ports.Add(port);

            Console.WriteLine($"Opened port {port}.");
        }

        static void NetListen(string arguments)
        {
            if (!int.TryParse(arguments, out int port))
            {
                Console.WriteLine("Invalid port number.");
                return;
            }

            if (!activeDevice.Ports.Contains(port))
                activeDevice.Ports.Add(port);

            activeDevice.ListeningPorts.Add(port);
            Console.WriteLine($"Now listening on port {port}.");
        }

        static void NetSend(string arguments)
        {
            if (currentConnectionPort == 0)
            {
                Console.WriteLine("Not connected to any device.");
                return;
            }

            if (!networkDevices.TryGetValue(currentConnectionPort, out var dev))
            {
                Console.WriteLine("Connection lost.");
                return;
            }

            dev.MessageQueue.Enqueue(arguments);
            Console.WriteLine($"Sent: {arguments}");
        }

        static void NetRecv()
        {
            if (currentConnectionPort == 0)
            {
                Console.WriteLine("Not connected to any device.");
                return;
            }

            if (!networkDevices.TryGetValue(currentConnectionPort, out var dev))
            {
                Console.WriteLine("Connection lost.");
                return;
            }

            if (dev.MessageQueue.Count == 0)
            {
                Console.WriteLine("No messages.");
                return;
            }

            string msg = dev.MessageQueue.Dequeue();
            Console.WriteLine($"Received: {msg}");
        }

        static void NetCheck(string arguments)
        {
            if (!int.TryParse(arguments, out int port))
            {
                Console.WriteLine("Invalid port number.");
                return;
            }

            if (!networkDevices.TryGetValue(port, out var dev))
            {
                Console.WriteLine($"Port {port}: No device");
                return;
            }

            Console.WriteLine($"Port {port}: Device '{dev.Name}'");
            Console.WriteLine($"  Open: {dev.Ports.Contains(port)}");
            Console.WriteLine($"  Listening: {dev.ListeningPorts.Contains(port)}");
        }

        static bool IsPathProtected(string path)
        {
            foreach (var pf in protectedFolders)
            {
                if (path.StartsWith(pf)) return true;
            }
            return lockedFiles.Contains(path);
        }

        static string GetExtension(string filename)
        {
            int lastDot = filename.LastIndexOf('.');
            return lastDot >= 0 ? filename.Substring(lastDot).ToLower() : "";
        }

        static void OpenTextFile(string path)
        {
            if (!activeDevice.Files.TryGetValue(path, out var content))
            {
                Console.WriteLine("File not found.");
                return;
            }
            Console.WriteLine(content);
        }

        static void LaunchApp(string path)
        {
            Console.WriteLine("Apps are not yet implemented.");
        }

        static void LaunchNano(string filePath)
        {
            Console.WriteLine($"=== nano: {filePath} ===");
            Console.WriteLine("Type your content. Commands: :wq = save & exit, :q = exit without saving");
            Console.WriteLine("-----------------------------------------------");

            string existing = "";
            if (activeDevice.Files.TryGetValue(filePath, out var ex))
            {
                existing = ex;
                Console.WriteLine("[Existing content:]");
                Console.WriteLine(existing);
                Console.WriteLine("[End of existing content. Type new content below (will replace existing):]");
            }

            var sb = new StringBuilder();
            while (true)
            {
                string line = Console.ReadLine() ?? "";
                if (line == ":wq")
                {
                    activeDevice.Files[filePath] = sb.ToString();
                    Console.WriteLine("File saved.");
                    break;
                }
                else if (line == ":q")
                {
                    Console.WriteLine("Exited without saving.");
                    break;
                }
                else
                {
                    sb.AppendLine(line);
                }
            }
        }

        static void EnsureDownloads(string path)
        {
            if (!activeDevice.Folders.ContainsKey(path))
                activeDevice.Folders[path] = new List<string>();
        }

        static JsonElement? ExtractHeaderFromPkg(string pkgText)
        {
            try
            {
                int headerStart = pkgText.IndexOf("{");
                int headerEnd = pkgText.IndexOf("}");
                if (headerStart >= 0 && headerEnd > headerStart)
                {
                    string headerJson = pkgText.Substring(headerStart, headerEnd - headerStart + 1);
                    using (JsonDocument doc = JsonDocument.Parse(headerJson))
                    {
                        return doc.RootElement.Clone();
                    }
                }
            }
            catch { }
            return null;
        }

        static Dictionary<string, string> ExtractFilesFromPkg(string pkgText)
        {
            var files = new Dictionary<string, string>();
            try
            {
                string marker = "===FILES===";
                int idx = pkgText.IndexOf(marker);
                if (idx >= 0)
                {
                    string filesSec = pkgText.Substring(idx + marker.Length).Trim();
                    var lines = filesSec.Split(new[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    string currentFile = "";
                    var content = new StringBuilder();

                    foreach (var line in lines)
                    {
                        if (line.StartsWith("[") && line.EndsWith("]"))
                        {
                            if (!string.IsNullOrEmpty(currentFile))
                                files[currentFile] = content.ToString().TrimEnd();
                            currentFile = line.Trim('[', ']');
                            content.Clear();
                        }
                        else if (!string.IsNullOrEmpty(currentFile))
                        {
                            content.AppendLine(line);
                        }
                    }

                    if (!string.IsNullOrEmpty(currentFile))
                        files[currentFile] = content.ToString().TrimEnd();
                }
            }
            catch { }
            return files;
        }

        static (bool success, string message, BldPackage pkg) ParseAndBuildBld(string source, string scriptPath)
        {
            var pkg = new BldPackage();
            var lines = source.Split('\n', StringSplitOptions.RemoveEmptyEntries);

            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line == "" || line.StartsWith("#")) continue;

                if (line.StartsWith("pkgname ", StringComparison.OrdinalIgnoreCase))
                {
                    pkg.PkgName = line.Substring(8).Trim().Trim('"');
                }
                else if (line.StartsWith("version ", StringComparison.OrdinalIgnoreCase))
                {
                    pkg.Version = line.Substring(8).Trim().Trim('"');
                }
                else if (line.StartsWith("outfile ", StringComparison.OrdinalIgnoreCase))
                {
                    pkg.OutFile = line.Substring(8).Trim().Trim('"');
                }
                else if (line.StartsWith("entry ", StringComparison.OrdinalIgnoreCase))
                {
                    pkg.Entry = line.Substring(6).Trim().Trim('"');
                }
                else if (line.StartsWith("file ", StringComparison.OrdinalIgnoreCase))
                {
                    var parts = line.Substring(5).Trim().Split(new[] { " as " }, StringSplitOptions.None);
                    if (parts.Length == 2)
                    {
                        string srcPath = parts[0].Trim().Trim('"');
                        string dstPath = parts[1].Trim().Trim('"');
                        if (activeDevice.Files.TryGetValue(srcPath, out var content))
                            pkg.FileContents[dstPath] = content;
                    }
                }
                else if (line.StartsWith("box ", StringComparison.OrdinalIgnoreCase))
                {
                    string boxName = line.Substring(4).Trim().Trim('"');
                    pkg.Boxes.Add(boxName);
                }
                else if (line.StartsWith("depends ", StringComparison.OrdinalIgnoreCase))
                {
                    string dep = line.Substring(8).Trim().Trim('"');
                    pkg.Depends.Add(dep);
                }
                else if (line.StartsWith("compress", StringComparison.OrdinalIgnoreCase))
                {
                    pkg.Compress = true;
                }
            }

            if (string.IsNullOrEmpty(pkg.PkgName))
                return (false, "No package name defined", pkg);

            return (true, "Build successful", pkg);
        }

        static string SerializePkg(BldPackage pkg)
        {
            var sb = new StringBuilder();

            sb.AppendLine("{");
            sb.AppendLine($"  \"name\": \"{pkg.PkgName}\",");
            sb.AppendLine($"  \"version\": \"{pkg.Version}\",");
            sb.AppendLine($"  \"entry\": \"{pkg.Entry}\"");
            sb.AppendLine("}");

            sb.AppendLine("===FILES===");
            foreach (var kvp in pkg.FileContents)
            {
                sb.AppendLine($"[{kvp.Key}]");
                sb.AppendLine(kvp.Value);
            }

            return sb.ToString();
        }

        static void RunBoxInteractive(string boxSource, string boxName)
        {
            Console.WriteLine($"=== Running Box: {boxName} ===");
            Console.WriteLine(boxSource);
            Console.WriteLine("=== Box ended ===");
        }
    }
}