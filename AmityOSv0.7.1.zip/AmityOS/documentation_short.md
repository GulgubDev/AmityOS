AmityOS © Gulgub, 2026
Version 0.6.0
The Syntax of Imagination
Created by GulgubDev




What is AmityOS?
AmityOS is a mock-operating system designed for recreation and testing with the user in mind, combining the simplicity of Windows and the power of Linux to create a powerful OS for all audiences.  







Documentation

Command List:
help - Shows this list
cd - Navigate to a directory (usage: cd <folder>)
cd .. - Navigate to a directory's parent
ls - List all folders and files
mkdir - Create a mock-directory (usage: mkdir <foldername>)
mkfle - Create a mock-file (usage: mkfle <filename>)
rm <file> - Delete a file (usage: rm <filename>)
rm * - Delete ALL files in the current directory
print - Prints any arguments to the console (usage: print <args>)
cls - Clears the screen
shutdown - Shuts down AmityOS
open - Opens and displays a file (usage: open <filename>)
cp - Copies a file (usage: cp <source> <destination>)
nano - Simple text editor (usage: nano <filename>)
install <name>.pkg - Install a package from the built-in package list into downloads
install list - List all installable packages
uninstall <name>.pkg - Remove a .pkg file from wherever it currently is
switch <port> - Switch control to device on port. The target device must be listening and must be connected to the host device.
probe - Scan network for devices + ports
ping <port> - Test if a device is reachable on that port
connect <port> - Connect to the device listening on that port
mkdvc <name> <port> - Create a new mock device with its own filesystem
openport <port> - Open a port on the active device
listen <port> - Begin listening on a port (device owning the port)
send <msg> - Send data to the connected device
recv - Receive data for the active device
check <port> - Show port status
pkgedit <name>.pkg - Edit any .pkg file using a modified nano command*
pkghelp - Displays the .pkgeditor documentation








Command Notation and Scripting for pkgbuild



LOGIC GATES AND CONDITIONALS:
* Any logic gate requires a conditional, state and action starter to execute a function
if <var> - IF conditional
then, #<func> - THEN action delimiter
<var> or <var> = - OR logic gate
<var> and <var> = - AND logic gate
<var> not = - NOT logic gate


DEFINITION
def $<var> - Define a variable.
setbool $<var> - Define a variable as a boolean variable.
bool $<var> = [true/false] - Define a boolean variable as true or false.
pkgname @<name> - Define the pkgname for install list, recommended.
dfunc #<name> - Define a function.


OPERATORS
= - Equality operator
, - Universal separator
- - Subtractor
+ - Additioner
; - End

EXECUTION
call #<func> - Call a function, which executes it.
rpcall #<func> <amount> [*] - Repeat-call a function any set amount of times.
endfunc - Ends a function
keycall #<func> <key>

EXECUTABLES AND PRESET FUNCTIONS
* Must be executed inside a function with a legal call command
end - Ends the .pkg
print - Output text to the console.
set - Assign a value to a variable.
inc - Increase a numeric variable by 1.
dec - Decrease a numeric variable by 1.
wait - Pause execution for a set time.
exit - Stop the current function immediately.
write - Write text to a file (overwrite).
append - Add text to the end of a file.
read - Display the contents of a file.
delete - Remove a file from the filesystem.
exists - Check if a file exists.
input - Read user input into a variable.
ask - Ask a question and store the answer.
confirm - Ask a yes/no question and store true/false.
rnd - Generate a random number.
comp - Compare two values and store the result.
goto - Jump to a label in the script.
label - Define a jump target.
loop - Begin a loop that repeats N times.
endloop - End a loop block.
break - Exit the current loop.
continue - Skip to the next loop iteration.
color - Change the console text color.
title - Set the console window title.
banner - Print stylized ASCII text.
clear - Clear the screen.
open - Open a file using AmityOS.
copy - Copy a file.
move - Move a file.
rename - Rename a file.
length - Get the length of a string.
substring - Extract part of a string.
concat - Combine two strings.
toupper - Convert text to uppercase.
tolower - Convert text to lowercase.
reverse - Reverse a string.
split - Split a string into parts.
join  - Join multiple strings together.
push - Push a value onto a stack.
pop - Pop a value from a stack.
peek - Read the top value of a stack.
size - Get the size of a list or stack.
sort - Sort a list.
shuffle - Randomize a list.
send - Send data to a connected device.
recv - Receive data into a variable.
connect - Connect to a port.
disconnect - Disconnect from a port.
listen - Begin listening on a port.
openport - Open a port on the device.
closeport - Close a port.
ping - Test if a device is reachable.
probe - Scan for devices and ports.
device - Switch or query device info.
mount - Mount a virtual filesystem.
unmount - Unmount a filesystem.
time - Get the current time.
date - Get the current date.
timestamp - Get the current timestamp.
sleep - Alias for wait.
flash  - Flash the screen or text.
alert - Show an alert message.
notify - Show a notification.
error - Display an error message.
success - Display a success message.
warning - Display a warning message.
log - Write to the system log.
debug - Output debug information.
trace - Output trace-level info.
system - Run a system-level command.
exec - Execute another `.pkg` file.
run - Run a built-in OS command.
spawn - Start a background task.
kill - Stop a running task.
restart - Restart the current `.pkg`.
reboot - Reboot the OS (mock).
shutdown - Shut down the OS.
load - Load data from a file into memory.
save - Save memory data to a file.
import - Import data or settings.
export - Export data or settings.
encrypt - Encrypt text or files.
decrypt - Decrypt text or files.
compress - Compress a file.
decompress - Decompress a file.
hash - Generate a hash of text or file.
checksum - Generate a checksum.
version - Get the current AmityOS version.
pkginfo - Get metadata about the running `.pkg`.
packagemeta  - Read or write `.pkg` metadata.
packageverify - Verify `.pkg` integrity.
packagesize - Get the size of the `.pkg`.
package - Get the package name.
packageid  - Get the package ID.
packageicon - Get or set the package icon.









*Once saved, the .pkg will be added to both Downloads and to install list.