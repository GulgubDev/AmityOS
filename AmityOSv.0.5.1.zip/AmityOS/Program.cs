﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace AmityOS
{
    // ----------------------------------------------------
    // Device model for mock networking
    // ----------------------------------------------------
    class Device
    {
        public string Name { get; set; }
        public List<int> Ports { get; set; } = new();
        public HashSet<int> ListeningPorts { get; set; } = new();
        public Dictionary<string, List<string>> Folders { get; set; }
        public Dictionary<string, string> Files { get; set; }
        public Queue<string> MessageQueue { get; set; } = new();
    }

    class Program
    {
        // ----------------------------------------------------
        // Global state (we operate on the activeDevice)
        // ----------------------------------------------------
        static Dictionary<int, Device> networkDevices = new(); // port -> device
        static int currentConnectionPort = 0;                  // 0 = no connection
        static string currentConnectionName = "";
        static string currentConnectionOwner = "";

        static Device hostDevice;
        static Device activeDevice;
        static int hostPort = 1000;                            // default host port
        static string activeFolder = "C:/";

        static Dictionary<string, Action<string>> appHandlers = new();

        // Hardcoded package repository (installable .pkg list)
        // Key: filename (e.g. "hello.pkg"), Value: opaque payload (simulated)
        // We will store the full .pkg file text as the payload string.
        static Dictionary<string, string> packageRepo = new()
        {
            // The payload is opaque; for this preset we don't need a real payload string.
            { "hello.pkg", "PRESET_HELLO_PAYLOAD" },
        };

        // Permissions data (populated from perms.cfg)
        static HashSet<string> protectedFolders = new();
        static HashSet<string> lockedFiles = new();
        static Dictionary<string, string> devicePasswords = new();

        // perms.cfg path (inside the host filesystem)
        const string PermsPath = "C:/os/config/perms.cfg";

        // ---------------- pkgbuild state helpers ----------------
        class BldPackage
        {
            public string PkgName = "";
            public string Version = "0.0";
            public string OutFile = "";
            public string Entry = "";
            public Dictionary<string, string> Meta = new();
            public List<string> Files = new();
            public List<string> Boxes = new();
            public Dictionary<string, string> FileContents = new(); // path -> raw text
            public bool Compress = false;
            public List<string> Depends = new();
        }

        static void Main(string[] args)
        {
            Console.Title = "AmityOS Kernel";
            Console.WriteLine("AmityOS Kernel v.0.5.1 loaded\n");
            Console.WriteLine("For more information, type help\n");

            // register handlers
            appHandlers[".txt"] = path => OpenTextFile(path);
            appHandlers[".app"] = path => LaunchApp(path);
            appHandlers[".pkg"] = path => RunPackage(path);
            appHandlers[".cfg"] = path => OpenTextFile(path);

            // create host filesystem
            var hostFolders = new Dictionary<string, List<string>>()
            {
                { "C:/",    new List<string> { "os", "user" } },
                { "C:/os/", new List<string> { "bin", "config" } },
                { "C:/os/bin/", new List<string>() },
                { "C:/os/config/", new List<string>() },
                { "C:/user/", new List<string> { "downloads" } },
                { "C:/user/downloads/", new List<string>() },
            };

            var hostFiles = new Dictionary<string, string>();

            // register host device (uses same filesystem as the console)
            hostDevice = new Device
            {
                Name = "host",
                Ports = new List<int> { hostPort },
                ListeningPorts = new HashSet<int>(),
                Folders = hostFolders,
                Files = hostFiles
            };
            networkDevices[hostPort] = hostDevice;

            // set active device to host by default
            activeDevice = hostDevice;
            activeFolder = "C:/";

            // start command loop
            CommandLoop();
        }

        // ----------------------------------------------------
        // Load perms.cfg and populate protectedFolders, lockedFiles, devicePasswords
        // ----------------------------------------------------
        static void LoadPerms()
        {
            protectedFolders.Clear();
            lockedFiles.Clear();
            devicePasswords.Clear();

            if (!activeDevice.Files.TryGetValue(PermsPath, out var content) || string.IsNullOrEmpty(content))
            {
                // nothing to load
                return;
            }

            string currentSection = "";
            var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line == "" || line.StartsWith("#")) continue;

                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    currentSection = line.ToLower();
                    continue;
                }

                switch (currentSection)
                {
                    case "[protected_folders]":
                        // normalize to end with slash
                        var pf = line.Replace("\\", "/");
                        if (!pf.EndsWith("/")) pf += "/";
                        protectedFolders.Add(pf);
                        break;

                    case "[locked_files]":
                        var lf = line.Replace("\\", "/");
                        lockedFiles.Add(lf);
                        break;

                    case "[device_passwords]":
                        var kv = line.Split('=', 2);
                        if (kv.Length == 2)
                        {
                            var name = kv[0].Trim();
                            var pass = kv[1].Trim();
                            if (!string.IsNullOrEmpty(name))
                                devicePasswords[name] = pass;
                        }
                        break;

                    default:
                        // unknown or no section — ignore
                        break;
                }
            }
        }

        // ----------------------------------------------------
        // Command loop (filesystem + networking + pkg commands)
        // ----------------------------------------------------
        static void CommandLoop()
        {
            while (true)
            {
                Console.Write($"[{activeDevice.Name}@{(activeDevice.Ports.Count > 0 ? activeDevice.Ports[0].ToString() : "?")}] {activeFolder}> ");
                string input = Console.ReadLine() ?? "";

                string[] parts = input.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 0) continue;

                string command = parts[0];
                string arguments = parts.Length > 1 ? parts[1] : "";

                // Basic commands
                if (command == "help")
                {
                    PrintHelp();
                }
                else if (command == "cd") CmdCd(arguments);
                else if (command == "ls") CmdLs();
                else if (command == "mkdir") CmdMkdir(arguments);
                else if (command == "mkfle") CmdMkfle(arguments);
                else if (command == "rm") CmdRm(arguments);
                else if (command == "cp") CmdCp(arguments);
                else if (command == "nano") CmdNano(arguments);
                else if (command == "open") CmdOpen(arguments);
                else if (command == "print") { if (arguments == "") Console.WriteLine("Incorrect usage of print. Usage: print <args>"); else Console.WriteLine(arguments); }
                else if (command == "cls" || command == "clear") { Console.Clear(); Console.WriteLine("AmityOS Kernel v.0.5.1 loaded\n"); Console.WriteLine("For more information, type help\n"); }
                else if (command == "shutdown") break;

                // Package commands
                else if (command == "install") CmdInstall(arguments);
                else if (command == "uninstall") CmdUninstall(arguments);
                else if (command == "pkgbuild") CmdPkgBuild(arguments);
                else if (command == "pkgedit") CmdPkgEdit(arguments);
                else if (command == "runbox") CmdRunBox(arguments);
                else if (command == "installpkg") CmdInstallPkg(arguments); // helper to add pkg content to repo

                // Device switching: only allowed if the target port is listening AND you're connected to it
                else if (command == "switch")
                {
                    if (arguments == "")
                    {
                        Console.WriteLine("Usage: switch <port>");
                    }
                    else if (!int.TryParse(arguments, out int port))
                    {
                        Console.WriteLine("Invalid port number.");
                    }
                    else if (!networkDevices.TryGetValue(port, out var dev))
                    {
                        Console.WriteLine("No device found on that port.");
                    }
                    else if (!dev.ListeningPorts.Contains(port))
                    {
                        Console.WriteLine($"Cannot switch: device '{dev.Name}' is not listening on port {port}.");
                    }
                    else if (currentConnectionPort != port)
                    {
                        Console.WriteLine($"Cannot switch: you are not connected to port {port}. Use connect {port} first.");
                    }
                    else
                    {
                        activeDevice = dev;
                        activeFolder = "C:/";
                        Console.WriteLine($"Switched to device '{dev.Name}' on port {port}.");
                    }
                }

                // Networking commands
                else if (command == "probe") NetProbe();
                else if (command == "ping") NetPing(arguments);
                else if (command == "connect") NetConnect(arguments);
                else if (command == "mkdvc") NetMkdvc(arguments);
                else if (command == "openport") NetOpenPort(arguments);
                else if (command == "listen") NetListen(arguments);
                else if (command == "send") NetSend(arguments);
                else if (command == "recv") NetRecv();
                else if (command == "check") NetCheck(arguments);

                else Console.WriteLine("That command is not recognized. Type help for a list of commands.");
            }
        }

        // ----------------------------------------------------
        // Filesystem command implementations (operate on activeDevice)
        // ----------------------------------------------------
        static void PrintHelp()
        {
            Console.WriteLine("Available commands:");
            Console.WriteLine("help - Shows this list");
            Console.WriteLine("cd - Navigate to a directory (usage: cd <folder>)");
            Console.WriteLine("cd .. - Navigate to a directory's parent");
            Console.WriteLine("ls - List all folders and files");
            Console.WriteLine("mkdir - Create a mock-directory (usage: mkdir <foldername>)");
            Console.WriteLine("mkfle - Create a mock-file (usage: mkfle <filename>)");
            Console.WriteLine("rm <file> - Delete a file (usage: rm <filename>)");
            Console.WriteLine("rm * - Delete ALL files in the current directory");
            Console.WriteLine("print - Prints any arguments to the console (usage: print <args>)");
            Console.WriteLine("cls - Clears the screen");
            Console.WriteLine("shutdown - Shuts down AmityOS");
            Console.WriteLine("open - Opens and displays a file (usage: open <filename>)");
            Console.WriteLine("cp - Copies a file (usage: cp <source> <destination>)");
            Console.WriteLine("nano - Simple text editor (usage: nano <filename>)");
            Console.WriteLine("install <name>.pkg - Install a package from the built-in package list into downloads");
            Console.WriteLine("install list - List all installable packages");
            Console.WriteLine("uninstall <name>.pkg - Remove a .pkg file from wherever it currently is");
            Console.WriteLine("pkgbuild <script.bld> - Build a .pkg from a .bld script");
            Console.WriteLine("pkgedit <script.bld> - Edit a .bld script; on save it will build and register the .pkg");
            Console.WriteLine("runbox <pkg> <BoxName> - Run an embedded box from a package");
            Console.WriteLine("installpkg <name>.pkg - Add a .pkg file content to the install list (dev helper)");
            Console.WriteLine("switch <port> - Switch control to device on port. Device must be listening and you must be connected to it.");
            Console.WriteLine("probe - Scan network for devices + ports");
            Console.WriteLine("ping <port> - Test if a device is reachable on that port");
            Console.WriteLine("connect <port> - Connect to the device listening on that port");
            Console.WriteLine("mkdvc <name> <port> - Create a new mock device with its own filesystem");
            Console.WriteLine("openport <port> - Open a port on the active device");
            Console.WriteLine("listen <port> - Begin listening on a port (device owning the port)");
            Console.WriteLine("send <msg> - Send data to the connected device");
            Console.WriteLine("recv - Receive data for the active device");
            Console.WriteLine("check <port> - Show port status");
            Console.WriteLine("");
            Console.Write("Note: AmityOS is not a real operating system. It cannot interact with your actual filesystem or network. All commands operate on a simulated environment within this console. AmityOS is work in progress and may have bugs, or incomplete features. Have fun experimenting!");
            Console.WriteLine("");
        }

        static void CmdCd(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: cd <folder>"); return; }
            if (arguments == "..") { activeFolder = "C:/"; return; }
            string target = activeFolder + arguments + "/";
            if (activeDevice.Folders.ContainsKey(target)) activeFolder = target;
            else Console.WriteLine("Folder not found.");
        }

        static void CmdLs()
        {
            foreach (var f in activeDevice.Folders[activeFolder]) Console.WriteLine($"<DIR> {f}");
            var fileList = activeDevice.Files.Keys.Where(f => f.StartsWith(activeFolder)).Select(f => f.Substring(activeFolder.Length));
            foreach (var file in fileList) Console.WriteLine(file);
        }

        static void CmdMkdir(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: mkdir <foldername>"); return; }
            string newPath = activeFolder + arguments + "/";
            // prevent creating inside protected folders
            foreach (var pf in protectedFolders)
            {
                if (activeFolder.StartsWith(pf))
                {
                    Console.WriteLine("Access denied: cannot modify protected folder.");
                    return;
                }
            }
            if (activeDevice.Folders.ContainsKey(newPath)) { Console.WriteLine("Folder already exists."); return; }
            activeDevice.Folders[activeFolder].Add(arguments);
            activeDevice.Folders[newPath] = new List<string>();
            Console.WriteLine($"Created folder '{arguments}'.");
        }

        static void CmdMkfle(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: mkfle <filename>"); return; }
            string filePath = activeFolder + arguments;
            // prevent creating files inside protected folders
            foreach (var pf in protectedFolders)
            {
                if (activeFolder.StartsWith(pf))
                {
                    Console.WriteLine("Access denied: cannot modify protected folder.");
                    return;
                }
            }
            if (activeDevice.Files.ContainsKey(filePath)) { Console.WriteLine("File already exists."); return; }
            activeDevice.Files[filePath] = "";
            Console.WriteLine($"Created file '{arguments}'.");
        }

        static void CmdRm(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: rm <filename> OR rm *"); return; }
            if (arguments == "*")
            {
                // prevent deleting files in protected folders
                var toDelete = activeDevice.Files.Keys.Where(f => f.StartsWith(activeFolder)).ToList();
                foreach (var f in toDelete)
                {
                    // if file is locked or inside protected folder, skip
                    if (IsPathProtected(f))
                    {
                        Console.WriteLine($"Skipped protected file: {f}");
                        continue;
                    }
                    activeDevice.Files.Remove(f);
                }
                Console.WriteLine("All deletable files deleted.");
                return;
            }
            string filePath = activeFolder + arguments;

            // prevent deleting perms.cfg
            if (filePath.Equals(PermsPath, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Access denied: perms.cfg is protected.");
                return;
            }

            if (!activeDevice.Files.ContainsKey(filePath)) { Console.WriteLine("File not found."); return; }

            // check locked or protected
            if (IsPathProtected(filePath))
            {
                Console.WriteLine("Access denied: file is protected or locked.");
                return;
            }

            activeDevice.Files.Remove(filePath);
            Console.WriteLine($"Deleted file '{arguments}'.");
        }

        static void CmdCp(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: cp <source> <destination>"); return; }
            string[] cpArgs = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (cpArgs.Length < 2) { Console.WriteLine("Usage: cp <source> <destination>"); return; }
            string source = activeFolder + cpArgs[0];
            string dest = activeFolder + cpArgs[1];

            if (!activeDevice.Files.ContainsKey(source)) { Console.WriteLine("Source file not found."); return; }

            // prevent copying into protected folders
            foreach (var pf in protectedFolders)
            {
                if (dest.StartsWith(pf))
                {
                    Console.WriteLine("Access denied: cannot copy into protected folder.");
                    return;
                }
            }

            if (activeDevice.Files.ContainsKey(dest)) { Console.WriteLine("Destination file already exists."); return; }
            activeDevice.Files[dest] = activeDevice.Files[source];
            Console.WriteLine($"Copied '{cpArgs[0]}' to '{cpArgs[1]}'.");
        }

        static void CmdNano(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: nano <filename>"); return; }

            string ext = GetExtension(arguments);
            if (ext == ".pkg")
            {
                Console.WriteLine("Cannot edit .pkg files.");
                return;
            }

            string filePath = activeFolder + arguments;
            LaunchNano(filePath);

            // If perms.cfg was edited, reload permissions
            if (filePath.Equals(PermsPath, StringComparison.OrdinalIgnoreCase))
            {
                LoadPerms();
                Console.WriteLine("Permissions reloaded from perms.cfg.");
            }
        }

        static void CmdOpen(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: open <filename>"); return; }
            string filePath = activeFolder + arguments;
            if (!activeDevice.Files.ContainsKey(filePath)) { Console.WriteLine("File not found."); return; }
            string ext = GetExtension(arguments);

            // .pkg: run the package, do NOT show contents
            if (ext == ".pkg")
            {
                RunPackage(filePath);
                return;
            }

            if (appHandlers.TryGetValue(ext, out var handler)) handler(filePath);
            else OpenTextFile(filePath);
        }

        // ----------------------------------------------------
        // Package commands
        // ----------------------------------------------------
        static void CmdInstall(string arguments)
        {
            if (arguments == "")
            {
                Console.WriteLine("Usage: install <name>.pkg OR install list");
                return;
            }

            if (arguments == "list")
            {
                Console.WriteLine("Installable packages:");
                foreach (var pkg in packageRepo.Keys)
                    Console.WriteLine($" - {pkg}");
                return;
            }

            if (!arguments.EndsWith(".pkg"))
            {
                Console.WriteLine("Package name must end with .pkg");
                return;
            }

            if (!packageRepo.TryGetValue(arguments, out var payload))
            {
                Console.WriteLine("That package is not in the install list.");
                return;
            }

            string downloadsPath = "C:/user/downloads/";
            if (!activeDevice.Folders.ContainsKey(downloadsPath))
            {
                // Ensure downloads folder exists on this device
                if (!activeDevice.Folders.ContainsKey("C:/user/"))
                    activeDevice.Folders["C:/user/"] = new List<string>();
                if (!activeDevice.Folders["C:/user/"].Contains("downloads"))
                    activeDevice.Folders["C:/user/"].Add("downloads");
                activeDevice.Folders[downloadsPath] = new List<string>();
            }

            string pkgPath = downloadsPath + arguments;

            if (!activeDevice.Files.ContainsKey(pkgPath))
            {
                activeDevice.Files[pkgPath] = payload;
                Console.WriteLine($"Installed {arguments} to downloads.");
            }
            else
            {
                Console.WriteLine($"{arguments} is already installed in downloads.");
            }
        }

        static void CmdUninstall(string arguments)
        {
            if (arguments == "")
            {
                Console.WriteLine("Usage: uninstall <name>.pkg");
                return;
            }

            if (!arguments.EndsWith(".pkg"))
            {
                Console.WriteLine("Package name must end with .pkg");
                return;
            }

            // Find the .pkg file anywhere on this device
            string foundKey = activeDevice.Files.Keys
                .FirstOrDefault(k => k.EndsWith("/" + arguments) || k.EndsWith(arguments));

            if (foundKey == null)
            {
                Console.WriteLine("Package file not found on this device.");
                return;
            }

            // prevent uninstalling perms.cfg if someone named it .pkg (defensive)
            if (foundKey.Equals(PermsPath, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Access denied: cannot uninstall perms.cfg.");
                return;
            }

            // check locked/protected
            if (IsPathProtected(foundKey))
            {
                Console.WriteLine("Access denied: package file is protected or locked.");
                return;
            }

            activeDevice.Files.Remove(foundKey);
            Console.WriteLine($"Uninstalled {arguments} from {foundKey}.");
        }

        // ----------------------------------------------------
        // Build system: pkgbuild and pkgedit
        // ----------------------------------------------------
        static void CmdPkgBuild(string arguments)
        {
            if (string.IsNullOrEmpty(arguments))
            {
                Console.WriteLine("Usage: pkgbuild <script.bld>");
                return;
            }

            string scriptPath = activeFolder + arguments;
            if (!activeDevice.Files.ContainsKey(scriptPath))
            {
                Console.WriteLine("Build script not found.");
                return;
            }

            string script = activeDevice.Files[scriptPath];
            var result = ParseAndBuildBld(script, scriptPath);
            if (!result.success)
            {
                Console.WriteLine($"Build failed: {result.message}");
                return;
            }

            // Write .pkg to out path (relative to current folder) and register in packageRepo
            string outPath = result.pkg.OutFile;
            if (string.IsNullOrEmpty(outPath))
            {
                outPath = $"{result.pkg.PkgName}-{result.pkg.Version}.pkg";
            }

            // Serialize .pkg
            string pkgText = SerializePkg(result.pkg);

            // Write to current folder and to downloads
            string pkgFilePath = activeFolder + outPath;
            activeDevice.Files[pkgFilePath] = pkgText;

            string downloadsPath = "C:/user/downloads/";
            if (!activeDevice.Folders.ContainsKey(downloadsPath))
            {
                if (!activeDevice.Folders.ContainsKey("C:/user/"))
                    activeDevice.Folders["C:/user/"] = new List<string>();
                if (!activeDevice.Folders["C:/user/"].Contains("downloads"))
                    activeDevice.Folders["C:/user/"].Add("downloads");
                activeDevice.Folders[downloadsPath] = new List<string>();
            }
            string pkgDownloadsPath = downloadsPath + outPath;
            activeDevice.Files[pkgDownloadsPath] = pkgText;

            // Register in packageRepo (store the .pkg text)
            packageRepo[outPath] = pkgText;

            Console.WriteLine($"Built package: {outPath}");
            Console.WriteLine($"Files included: {result.pkg.Files.Count}  Boxes: {result.pkg.Boxes.Count}");
        }

        // Opens a .bld in nano; when saved, automatically runs pkgbuild and registers the .pkg
        static void CmdPkgEdit(string arguments)
        {
            if (string.IsNullOrEmpty(arguments))
            {
                Console.WriteLine("Usage: pkgedit <script.bld>");
                return;
            }

            string scriptPath = activeFolder + arguments;
            LaunchNano(scriptPath);

            // After nano returns, if the script exists, run the builder automatically
            if (activeDevice.Files.ContainsKey(scriptPath))
            {
                Console.WriteLine("Saved. Running pkgbuild...");
                CmdPkgBuild(arguments);
            }
            else
            {
                Console.WriteLine("Script not saved; build skipped.");
            }
        }

        // Helper to add a .pkg text into packageRepo (dev helper)
        static void CmdInstallPkg(string arguments)
        {
            if (string.IsNullOrEmpty(arguments))
            {
                Console.WriteLine("Usage: installpkg <name>.pkg");
                return;
            }

            string pkgPath = activeFolder + arguments;
            if (!activeDevice.Files.TryGetValue(pkgPath, out var pkgText))
            {
                Console.WriteLine("File not found.");
                return;
            }

            packageRepo[arguments] = pkgText;
            Console.WriteLine($"Added {arguments} to installable packages.");
        }

        // Run a box from a package: runbox <pkg> <BoxName>
        static void CmdRunBox(string arguments)
        {
            if (string.IsNullOrEmpty(arguments))
            {
                Console.WriteLine("Usage: runbox <pkg> <BoxName>");
                return;
            }

            var parts = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 2)
            {
                Console.WriteLine("Usage: runbox <pkg> <BoxName>");
                return;
            }

            string pkgName = parts[0];
            string boxName = parts[1];

            if (!packageRepo.TryGetValue(pkgName, out var pkgText))
            {
                Console.WriteLine("Package not found in repo.");
                return;
            }

            // Parse header to find box file path
            var header = ExtractHeaderFromPkg(pkgText);
            if (header == null)
            {
                Console.WriteLine("Invalid package format.");
                return;
            }

            if (!header.TryGetValue("boxes", out var boxesElement) || boxesElement.ValueKind == JsonValueKind.Null)

            {
                Console.WriteLine("No boxes in package.");
                return;
            }

            // boxesElement is JsonElement array
            try
            {
                var boxes = JsonSerializer.Deserialize<List<string>>(boxesElement.ToString());
                if (boxes == null || !boxes.Contains(boxName))
                {
                    Console.WriteLine($"Box '{boxName}' not found in package.");
                    return;
                }
            }
            catch
            {
                // fallback: try to find file by path boxes/<boxName>.box
            }

            // Extract the box file content from payload
            string boxPath = $"boxes/{boxName}.box";
            var fileContents = ExtractFilesFromPkg(pkgText);
            if (!fileContents.TryGetValue(boxPath, out var boxSource))
            {
                Console.WriteLine($"Box file '{boxPath}' not found in package payload.");
                return;
            }

            // Parse box source and run interactive loop
            RunBoxInteractive(boxSource, boxName);
        }

        // ----------------------------------------------------
        // Parser and builder for .bld scripts
        // ----------------------------------------------------
        static (bool success, string message, BldPackage pkg) ParseAndBuildBld(string script, string scriptPath)
        {
            var pkg = new BldPackage();
            var vars = new Dictionary<string, string>();
            var included = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var excluded = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var lines = script.Split('\n');
            bool inIf = false;
            bool ifResult = false;
            bool inBox = false;
            string currentBoxName = null;
            var currentBoxBuilder = new StringBuilder();
            int lineNo = 0;

            foreach (var raw in lines)
            {
                lineNo++;
                var line = raw.Trim();
                if (line == "" || line.StartsWith("#")) continue;

                // variable substitution for ${name}
                line = SubstituteVars(line, vars);

                // handle box blocks specially: capture raw source between box ... endbox
                if (inBox)
                {
                    if (line.StartsWith("endbox", StringComparison.OrdinalIgnoreCase))
                    {
                        // finish box
                        inBox = false;
                        string boxSource = currentBoxBuilder.ToString();
                        string boxPath = $"boxes/{currentBoxName}.box";
                        if (!included.Contains(boxPath))
                        {
                            included.Add(boxPath);
                            pkg.Files.Add(boxPath);
                            pkg.FileContents[boxPath] = boxSource;
                        }
                        pkg.Boxes.Add(currentBoxName);
                        currentBoxName = null;
                        currentBoxBuilder.Clear();
                        continue;
                    }
                    else
                    {
                        currentBoxBuilder.AppendLine(raw); // preserve original raw line
                        continue;
                    }
                }

                // parse tokens
                // support forms: cmd arg   or cmd ("arg with spaces") or cmd "arg"
                var m = Regex.Match(line, @"^(\w+)\s*(.*)$");
                if (!m.Success) continue;
                var cmd = m.Groups[1].Value.ToLower();
                var rest = m.Groups[2].Value.Trim();

                // helper to extract a single argument (supports "..." or (...) or bare)
                string ArgSingle(string s)
                {
                    s = s.Trim();
                    if (s.StartsWith("(") && s.EndsWith(")")) return s.Substring(1, s.Length - 2).Trim().Trim('"');
                    if (s.StartsWith("\"") && s.EndsWith("\"")) return s.Substring(1, s.Length - 2);
                    return s;
                }

                switch (cmd)
                {
                    case "pkgname":
                        pkg.PkgName = ArgSingle(rest);
                        break;
                    case "version":
                        pkg.Version = ArgSingle(rest);
                        break;
                    case "out":
                        pkg.OutFile = ArgSingle(rest);
                        break;
                    case "include":
                        {
                            var p = ArgSingle(rest);
                            string resolved = ResolvePathRelativeToScript(p, scriptPath);
                            if (!included.Contains(resolved) && !excluded.Contains(resolved))
                            {
                                included.Add(resolved);
                                pkg.Files.Add(resolved);
                                // read file content from activeDevice
                                if (activeDevice.Files.TryGetValue(resolved, out var content))
                                {
                                    pkg.FileContents[resolved] = content;
                                }
                                else
                                {
                                    Console.WriteLine($"Warning: included file '{resolved}' not found.");
                                    pkg.FileContents[resolved] = "";
                                }
                            }
                        }
                        break;
                    case "include-dir":
                        {
                            var dir = ArgSingle(rest);
                            string resolvedDir = ResolvePathRelativeToScript(dir, scriptPath);
                            // find all files under that folder in activeDevice.Files
                            var keys = activeDevice.Files.Keys.Where(k => k.StartsWith(resolvedDir)).ToList();
                            foreach (var k in keys)
                            {
                                if (!included.Contains(k) && !excluded.Contains(k))
                                {
                                    included.Add(k);
                                    pkg.Files.Add(k);
                                    pkg.FileContents[k] = activeDevice.Files[k];
                                }
                            }
                        }
                        break;
                    case "exclude":
                        {
                            var p = ArgSingle(rest);
                            string resolved = ResolvePathRelativeToScript(p, scriptPath);
                            excluded.Add(resolved);
                            if (pkg.Files.Contains(resolved)) pkg.Files.Remove(resolved);
                            if (pkg.FileContents.ContainsKey(resolved)) pkg.FileContents.Remove(resolved);
                        }
                        break;
                    case "entry":
                        pkg.Entry = ArgSingle(rest);
                        break;
                    case "meta":
                        {
                            var partsMeta = rest.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                            if (partsMeta.Length >= 2)
                            {
                                var k = partsMeta[0];
                                var v = ArgSingle(partsMeta[1]);
                                pkg.Meta[k] = v;
                            }
                        }
                        break;
                    case "depends":
                        {
                            var list = ArgSingle(rest);
                            var arr = list.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim());
                            pkg.Depends.AddRange(arr);
                        }
                        break;
                    case "compress":
                        {
                            var v = ArgSingle(rest).ToLower();
                            pkg.Compress = v == "on" || v == "true";
                        }
                        break;
                    case "var":
                        {
                            var partsVar = rest.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                            if (partsVar.Length >= 2)
                            {
                                vars[partsVar[0]] = ArgSingle(partsVar[1]);
                            }
                        }
                        break;
                    case "if":
                        {
                            // only support: if <var> == <value>
                            var mm = Regex.Match(rest, @"^(\w+)\s*==\s*(.+)$");
                            if (mm.Success)
                            {
                                var vname = mm.Groups[1].Value;
                                var vval = ArgSingle(mm.Groups[2].Value.Trim());
                                inIf = true;
                                ifResult = vars.ContainsKey(vname) && vars[vname] == vval;
                            }
                            else
                            {
                                Console.WriteLine($"Parse error on if at line {lineNo}");
                                return (false, "Invalid if syntax", null);
                            }
                        }
                        break;
                    case "end":
                        {
                            inIf = false;
                            ifResult = false;
                        }
                        break;
                    case "print":
                        {
                            var text = ArgSingle(rest);
                            Console.WriteLine(text);
                        }
                        break;
                    case "fail":
                        {
                            var msg = ArgSingle(rest);
                            return (false, msg, null);
                        }
                    case "box":
                        {
                            // begin box capture until endbox
                            var boxName = ArgSingle(rest);
                            if (string.IsNullOrEmpty(boxName))
                            {
                                Console.WriteLine($"Invalid box name at line {lineNo}");
                                return (false, "Invalid box name", null);
                            }
                            inBox = true;
                            currentBoxName = boxName;
                            currentBoxBuilder.Clear();
                            // store the box header line as well
                            currentBoxBuilder.AppendLine(raw);
                        }
                        break;
                    default:
                        // unknown command: ignore or warn
                        Console.WriteLine($"Warning: unknown command '{cmd}' at line {lineNo}");
                        break;
                }
            }

            // apply excludes
            foreach (var ex in excluded)
            {
                if (pkg.Files.Contains(ex)) pkg.Files.Remove(ex);
                if (pkg.FileContents.ContainsKey(ex)) pkg.FileContents.Remove(ex);
            }

            // final validation
            if (string.IsNullOrEmpty(pkg.PkgName))
            {
                return (false, "pkgname is required", null);
            }
            if (string.IsNullOrEmpty(pkg.OutFile))
            {
                pkg.OutFile = $"{pkg.PkgName}-{pkg.Version}.pkg";
            }

            // ensure entry exists in payload if set
            if (!string.IsNullOrEmpty(pkg.Entry))
            {
                if (!pkg.Files.Contains(pkg.Entry))
                {
                    return (false, $"entry '{pkg.Entry}' not included in package", null);
                }
            }

            return (true, "OK", pkg);
        }

        // Replace ${name} with vars[name]
        static string SubstituteVars(string line, Dictionary<string, string> vars)
        {
            return Regex.Replace(line, @"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", m =>
            {
                var n = m.Groups[1].Value;
                return vars.TryGetValue(n, out var v) ? v : "";
            });
        }

        // Resolve relative paths: scriptPath is like C:/folder/script.bld
        static string ResolvePathRelativeToScript(string path, string scriptPath)
        {
            path = path.Replace("\\", "/").Trim();
            if (path.StartsWith("C:/")) return path;
            // scriptPath may be "C:/folder/script.bld" -> base "C:/folder/"
            var idx = scriptPath.LastIndexOf('/');
            var baseDir = idx >= 0 ? scriptPath.Substring(0, idx + 1) : activeFolder;
            return baseDir + path;
        }

        // Serialize package into single-file .pkg format
        static string SerializePkg(BldPackage pkg)
        {
            // header object
            var header = new Dictionary<string, object>();
            header["pkgname"] = pkg.PkgName;
            header["version"] = pkg.Version;
            header["entry"] = pkg.Entry;
            header["meta"] = pkg.Meta;
            header["boxes"] = pkg.Boxes;
            header["files"] = pkg.Files;
            header["compress"] = pkg.Compress;
            header["depends"] = pkg.Depends;

            string headerJson = JsonSerializer.Serialize(header);

            var sb = new StringBuilder();
            sb.AppendLine("---PKG-HEADER---");
            sb.AppendLine(headerJson);
            sb.AppendLine("---END HEADER---");

            foreach (var file in pkg.Files)
            {
                sb.AppendLine($"---FILE:{file}---");
                if (pkg.FileContents.TryGetValue(file, out var content))
                {
                    var bytes = Encoding.UTF8.GetBytes(content);
                    var b64 = Convert.ToBase64String(bytes);
                    sb.AppendLine(b64);
                }
                else
                {
                    sb.AppendLine(""); // empty
                }
                sb.AppendLine("---END FILE---");
            }

            sb.AppendLine("---PKG-END---");
            return sb.ToString();
        }

        // Extract header JSON as dictionary from .pkg text
        static Dictionary<string, JsonElement> ExtractHeaderFromPkg(string pkgText)
        {
            var lines = pkgText.Split('\n');
            int i = 0;
            while (i < lines.Length && !lines[i].StartsWith("---PKG-HEADER---")) i++;
            if (i >= lines.Length) return null;
            i++;
            if (i >= lines.Length) return null;
            var headerJson = lines[i].Trim();
            try
            {
                var doc = JsonDocument.Parse(headerJson);
                var root = doc.RootElement;
                var dict = new Dictionary<string, JsonElement>();
                foreach (var prop in root.EnumerateObject())
                {
                    dict[prop.Name] = prop.Value;
                }
                return dict;
            }
            catch
            {
                return null;
            }
        }

        // Extract files from .pkg text into dictionary path->content
        static Dictionary<string, string> ExtractFilesFromPkg(string pkgText)
        {
            var result = new Dictionary<string, string>();
            var lines = pkgText.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                if (line.StartsWith("---FILE:"))
                {
                    var path = line.Substring(8, line.Length - 11); // remove ---FILE: and ---
                    i++;
                    var b64 = new StringBuilder();
                    while (i < lines.Length && !lines[i].StartsWith("---END FILE---"))
                    {
                        b64.AppendLine(lines[i]);
                        i++;
                    }
                    var b64str = b64.ToString().Trim();
                    if (!string.IsNullOrEmpty(b64str))
                    {
                        try
                        {
                            var bytes = Convert.FromBase64String(b64str);
                            var content = Encoding.UTF8.GetString(bytes);
                            result[path] = content;
                        }
                        catch
                        {
                            result[path] = "";
                        }
                    }
                    else
                    {
                        result[path] = "";
                    }
                }
            }
            return result;
        }

        // ----------------------------------------------------
        // Run a box interactive loop given box source text
        // ----------------------------------------------------
        static void RunBoxInteractive(string boxSource, string boxName)
        {
            // Very small parser for box: find prompt and on key handlers
            string prompt = $"[{boxName}]>";
            var handlers = new Dictionary<string, List<string>>(); // key -> actions (lines)
            var lines = boxSource.Split('\n');
            string currentKey = null;
            bool inHandler = false;
            bool inThen = false;
            var actionBuffer = new List<string>();

            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line == "" || line.StartsWith("#")) continue;
                if (line.StartsWith("prompt", StringComparison.OrdinalIgnoreCase))
                {
                    var rest = line.Substring(6).Trim();
                    if (rest.StartsWith("(") && rest.EndsWith(")")) prompt = ArgSingle(rest);
                    else if (rest.StartsWith("\"") && rest.EndsWith("\"")) prompt = rest.Substring(1, rest.Length - 2);
                    else prompt = rest;
                    continue;
                }

                if (line.StartsWith("on key", StringComparison.OrdinalIgnoreCase))
                {
                    // on key "x"
                    var m = Regex.Match(line, @"on key\s+[""']?(.+?)[""']?$", RegexOptions.IgnoreCase);
                    if (m.Success)
                    {
                        currentKey = m.Groups[1].Value;
                        inHandler = true;
                        inThen = false;
                        actionBuffer.Clear();
                    }
                    continue;
                }

                if (inHandler && line.Equals("then", StringComparison.OrdinalIgnoreCase))
                {
                    inThen = true;
                    continue;
                }

                if (inHandler && line.Equals("end", StringComparison.OrdinalIgnoreCase))
                {
                    // commit handler
                    if (currentKey != null)
                    {
                        handlers[currentKey] = new List<string>(actionBuffer);
                    }
                    currentKey = null;
                    inHandler = false;
                    inThen = false;
                    actionBuffer.Clear();
                    continue;
                }

                if (inThen)
                {
                    actionBuffer.Add(line);
                }
            }

            // interactive loop: read single key (or line) and dispatch
            Console.WriteLine($"Entering box: {boxName}. Press keys to trigger handlers. Type 'exit' to leave.");
            while (true)
            {
                Console.Write(prompt + " ");
                string input = Console.ReadLine() ?? "";
                if (input == "exit") break;
                string key = input.Length > 0 ? input : "ENTER";

                // match exact key or wildcard "*"
                List<string> actions = null;
                if (handlers.TryGetValue(key, out actions) || handlers.TryGetValue("*", out actions))
                {
                    foreach (var act in actions)
                    {
                        // simple action parser: print("..."), run <app>, open <file>, exitbox, send "..."
                        var t = act.Trim();
                        if (t.StartsWith("print", StringComparison.OrdinalIgnoreCase))
                        {
                            var arg = t.Substring(5).Trim();
                            Console.WriteLine(ArgSingle(arg));
                        }
                        else if (t.StartsWith("run ", StringComparison.OrdinalIgnoreCase))
                        {
                            var arg = t.Substring(4).Trim();
                            var path = activeFolder + ArgSingle(arg);
                            LaunchApp(path);
                        }
                        else if (t.StartsWith("open ", StringComparison.OrdinalIgnoreCase))
                        {
                            var arg = t.Substring(5).Trim();
                            var path = activeFolder + ArgSingle(arg);
                            CmdOpen(ArgSingle(arg));
                        }
                        else if (t.StartsWith("send ", StringComparison.OrdinalIgnoreCase))
                        {
                            var arg = t.Substring(5).Trim();
                            NetSend(ArgSingle(arg));
                        }
                        else if (t.Equals("exitbox", StringComparison.OrdinalIgnoreCase))
                        {
                            Console.WriteLine("Exiting box.");
                            return;
                        }
                        else
                        {
                            Console.WriteLine($"[box] Unknown action: {t}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("No handler for that key.");
                }
            }
        }

        static string ArgSingle(string s)
        {
            s = s.Trim();
            if (s.StartsWith("(") && s.EndsWith(")")) return s.Substring(1, s.Length - 2).Trim().Trim('"');
            if (s.StartsWith("\"") && s.EndsWith("\"")) return s.Substring(1, s.Length - 2);
            return s;
        }

        // ----------------------------------------------------
        // RunPackage: improved to parse header and optionally run entry
        // ----------------------------------------------------
        static void RunPackage(string path)
        {
            string filename = path.Substring(path.LastIndexOf('/') + 1);
            if (!activeDevice.Files.TryGetValue(path, out var pkgText))
            {
                Console.WriteLine("Package file not found.");
                return;
            }

            // If it's the preset hello.pkg, keep behavior
            if (filename.Equals("hello.pkg", StringComparison.OrdinalIgnoreCase) && pkgText == "PRESET_HELLO_PAYLOAD")
            {
                Console.WriteLine("Hello World!");
                return;
            }

            // Try to parse header and run entry if present
            var header = ExtractHeaderFromPkg(pkgText);
            if (header == null)
            {
                Console.WriteLine($"Executing package: {filename}");
                Console.WriteLine("(Package payload is opaque and provided by the developer.)");
                return;
            }

            // If entry exists, extract file and run as app
            if (header.TryGetValue("entry", out var entryElem))
            {
                var entry = entryElem.GetString();
                if (!string.IsNullOrEmpty(entry))
                {
                    var files = ExtractFilesFromPkg(pkgText);
                    if (files.TryGetValue(entry, out var entryContent))
                    {
                        // write entry file into activeDevice.Files under a temp path and run it
                        string tempPath = activeFolder + entry;
                        activeDevice.Files[tempPath] = entryContent;
                        LaunchApp(tempPath);
                        return;
                    }
                }
            }

            Console.WriteLine($"Executed package: {filename} (no runnable entry found)");
        }

        // ----------------------------------------------------
        // Helpers: extension, nano, open text, app runner (operate on activeDevice)
        // ----------------------------------------------------
        static string GetExtension(string filename)
        {
            int dot = filename.LastIndexOf('.');
            if (dot == -1) return "";
            return filename.Substring(dot).ToLower();
        }

        static void LaunchNano(string filePath)
        {
            string filename = filePath.Substring(filePath.LastIndexOf('/') + 1);
            if (!activeDevice.Files.ContainsKey(filePath)) { activeDevice.Files[filePath] = ""; Console.WriteLine($"Created new file '{filename}'."); }
            Console.WriteLine($"--- nano: editing {filename} ---");
            Console.WriteLine("(Type your text. Use :wq to save and exit, :q to exit without saving.)");
            string originalContent = activeDevice.Files[filePath];
            string newContent = "";
            if (!string.IsNullOrEmpty(originalContent)) Console.WriteLine(originalContent);
            while (true)
            {
                string line = Console.ReadLine() ?? "";
                if (line == ":wq") { activeDevice.Files[filePath] = newContent; Console.WriteLine("Saved."); break; }
                else if (line == ":q") { Console.WriteLine("Exited without saving."); break; }
                else newContent += line + "\n";
            }
        }

        static void OpenTextFile(string filePath)
        {
            if (!activeDevice.Files.TryGetValue(filePath, out var content) || string.IsNullOrEmpty(content)) Console.WriteLine("(empty file)");
            else Console.WriteLine(content);
        }

        static void LaunchApp(string path)
        {
            Console.WriteLine($"Running application: {path}");
            if (!activeDevice.Files.ContainsKey(path)) { Console.WriteLine("App file missing."); return; }
            string[] lines = activeDevice.Files[path].Split('\n', StringSplitOptions.RemoveEmptyEntries);
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line == "") continue;
                string[] parts = line.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                string cmd = parts[0];
                string args = parts.Length > 1 ? parts[1] : "";
                switch (cmd)
                {
                    case "print": Console.WriteLine(args); break;
                    case "run": { string nestedPath = activeFolder + args; LaunchApp(nestedPath); break; }
                    case "nano": { string filePath = activeFolder + args; LaunchNano(filePath); break; }
                    default: Console.WriteLine($"[app] Unknown command: {cmd}"); break;
                }
            }
        }

        // ----------------------------------------------------
        // Utility: check if a path is protected or locked
        // ----------------------------------------------------
        static bool IsPathProtected(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            var normalized = path.Replace("\\", "/");

            // exact locked file match
            if (lockedFiles.Contains(normalized)) return true;

            // check if inside a protected folder
            foreach (var pf in protectedFolders)
            {
                if (normalized.StartsWith(pf, StringComparison.OrdinalIgnoreCase)) return true;
            }

            return false;
        }

        // ----------------------------------------------------
        // Networking implementations (operate globally, but actions apply to devices; send/recv use activeDevice)
        // ----------------------------------------------------

        // probe: list devices and their ports
        static void NetProbe()
        {
            Console.WriteLine("Scanning local network...\n");
            if (networkDevices.Count == 0) { Console.WriteLine("(no devices)"); return; }
            // group by device identity to avoid duplicates when device owns multiple ports
            var seen = new HashSet<Device>();
            foreach (var kv in networkDevices.OrderBy(k => k.Key))
            {
                var dev = kv.Value;
                if (seen.Contains(dev)) continue;
                seen.Add(dev);
                string ports = dev.Ports.Count > 0 ? string.Join(", ", dev.Ports) : "(no ports)";
                string listening = dev.ListeningPorts.Count > 0 ? string.Join(", ", dev.ListeningPorts) : "none";
                Console.WriteLine($"Device: {dev.Name}    Ports: {ports}    Listening: {listening}");
            }
        }

        // ping <port>: check if device exists and is listening
        static void NetPing(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: ping <port>"); return; }
            if (!int.TryParse(arguments, out int port)) { Console.WriteLine("Invalid port number."); return; }
            if (!networkDevices.TryGetValue(port, out var dev)) { Console.WriteLine("No device found on that port."); return; }
            if (dev.ListeningPorts.Contains(port)) Console.WriteLine($"Reply from {dev.Name}: port {port} open");
            else Console.WriteLine($"No reply: device '{dev.Name}' has port {port} but it's not listening");
        }

        // connect <port>: set current connection if target is listening
        static void NetConnect(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: connect <port>"); return; }
            if (!int.TryParse(arguments, out int port)) { Console.WriteLine("Invalid port number."); return; }
            if (!networkDevices.TryGetValue(port, out var dev)) { Console.WriteLine("No device found on that port."); return; }
            if (!dev.ListeningPorts.Contains(port)) { Console.WriteLine($"Device '{dev.Name}' is not listening on port {port}."); return; }
            currentConnectionPort = port;
            currentConnectionName = dev.Name;
            currentConnectionOwner = activeDevice.Name;
            Console.WriteLine($"Connected from '{activeDevice.Name}' to device '{dev.Name}' on port {port}.");
        }

        // mkdvc <name> <port>: create a new mock device with its own filesystem
        static void NetMkdvc(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: mkdvc <name> <port>"); return; }
            string[] a = arguments.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (a.Length < 2 || !int.TryParse(a[1], out int port)) { Console.WriteLine("Usage: mkdvc <name> <port>"); return; }
            string name = a[0];
            if (networkDevices.ContainsKey(port)) { Console.WriteLine($"Port {port} is already in use."); return; }

            var devFolders = new Dictionary<string, List<string>>()
            {
                { "C:/", new List<string> { "os", "user" } },
                { "C:/os/", new List<string>() },
                { "C:/user/", new List<string> { "downloads" } },
                { "C:/user/downloads/", new List<string>() }
            };
            var devFiles = new Dictionary<string, string>();

            var device = new Device
            {
                Name = name,
                Ports = new List<int> { port },
                ListeningPorts = new HashSet<int>(),
                Folders = devFolders,
                Files = devFiles
            };

            networkDevices[port] = device;
            Console.WriteLine($"Created device '{name}' on port {port}.");
        }

        // openport <port>: open a port on the active device (device owns the port)
        static void NetOpenPort(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: openport <port>"); return; }
            if (!int.TryParse(arguments, out int port)) { Console.WriteLine("Invalid port number."); return; }
            if (activeDevice.Ports.Contains(port)) { Console.WriteLine($"Port {port} is already open on {activeDevice.Name}."); return; }
            activeDevice.Ports.Add(port);
            networkDevices[port] = activeDevice;
            Console.WriteLine($"Port {port} opened on device '{activeDevice.Name}'.");
        }

        // listen <port>: device owning the port begins listening
        static void NetListen(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: listen <port>"); return; }
            if (!int.TryParse(arguments, out int port)) { Console.WriteLine("Invalid port number."); return; }
            if (!networkDevices.TryGetValue(port, out var dev)) { Console.WriteLine($"Port {port}: no device registered."); return; }
            dev.ListeningPorts.Add(port);
            Console.WriteLine($"Device '{dev.Name}' is now listening on port {port}.");
        }

        // send <msg>: send data to the currently connected port (appends to target device queue)
        static void NetSend(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: send <message>"); return; }
            if (currentConnectionPort == 0) { Console.WriteLine("Not connected to any device. Use connect <port> first."); return; }
            if (!networkDevices.TryGetValue(currentConnectionPort, out var target)) { Console.WriteLine("Target device disappeared."); return; }
            target.MessageQueue.Enqueue($"From {activeDevice.Name}: {arguments}");
            Console.WriteLine($"Sent from {activeDevice.Name} to {target.Name}: {arguments}");
        }

        // recv: receive messages queued for the active device
        static void NetRecv()
        {
            if (activeDevice.MessageQueue.Count == 0) { Console.WriteLine("No messages."); return; }
            while (activeDevice.MessageQueue.Count > 0)
            {
                Console.WriteLine(activeDevice.MessageQueue.Dequeue());
            }
        }

        // check <port>: show port status and queued messages
        static void NetCheck(string arguments)
        {
            if (arguments == "") { Console.WriteLine("Usage: check <port>"); return; }
            if (!int.TryParse(arguments, out int port)) { Console.WriteLine("Invalid port number."); return; }
            if (!networkDevices.TryGetValue(port, out var dev)) { Console.WriteLine($"Port {port}: no device registered."); return; }
            bool isListening = dev.ListeningPorts.Contains(port);
            bool isHost = ReferenceEquals(dev, hostDevice);
            bool isConnected = currentConnectionPort == port;
            int queued = dev.MessageQueue.Count;
            Console.WriteLine($"Port {port}: device='{dev.Name}' host={(isHost ? "yes" : "no")} listening={(isListening ? "yes" : "no")} connected={(isConnected ? "yes" : "no")} messages_queued={queued}");
        }
    }
}
